export type UserRole='Customer'|'Admin'|'Surveyor';
export interface LoginRequest{email:string;password:string}
export interface LoginResponse{accessToken:string;refreshToken:string;userId:string;email:string;role:UserRole;expiresIn?:number}
export interface Profile{userId:string;email:string;role:UserRole;isActive?:boolean;fullName?:string;phone?:string;address?:string}
export interface CustomerRegister{fullName:string;email:string;phone:string;address:string;password:string}
export interface SurveyorRegister{fullName:string;email:string;phone:string;address:string;qualification:string;licenseNumber:string;experienceYears:number;password:string}
export interface CreateUser{email:string;password:string;role:UserRole}
