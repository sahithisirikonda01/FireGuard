export type ClaimStatus='PendingAssignment'|'Assigned'|'UnderInvestigation'|'SurveySubmitted'|'Approved'|'Rejected';export type DocumentType='CustomerEvidence'|'SurveyorEvidence'|'SurveyReport';
export interface CreateClaim{policyId:number;incidentDate:string;incidentDescription:string;incidentLocation:string;estimatedLossAmount:number}
export interface Claim{id:number;claimNumber:string;userId:string;policyId:number;policyNumber:string;productName:string;incidentDescription:string;incidentDate:string;incidentLocation:string;estimatedLossAmount:number;surveyorId?:number;surveyorReport?:string;recommendedAmount?:number;adminRemarks?:string;status:ClaimStatus;createdAt:string;updatedAt?:string}
export interface Surveyor{id:number;userId:string;fullName:string;email:string;phone:string;address:string;qualification:string;licenseNumber:string;experienceYears:number;status:'Pending'|'Approved'|'Rejected';createdAt:string}
export interface SurveyReport{surveyorReport:string;recommendedAmount:number}
export interface Document{ id:number;claimId:number;fileName:string;contentType:string;fileSize:number;documentType:DocumentType;uploadedByUserId:string;uploadedAt:string}
