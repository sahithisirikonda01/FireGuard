export interface Customer{ id:number;userId:string;fullName:string;email:string;phone:string;address:string;createdAt:string }
