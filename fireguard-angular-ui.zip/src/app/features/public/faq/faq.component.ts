import {Component} from '@angular/core';@Component({selector:'app-faq',standalone:true,templateUrl:'./faq.component.html'})export class FaqComponent{}
