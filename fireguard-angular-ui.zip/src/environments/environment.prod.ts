export const environment = {
  production: true,
  gatewayUrl: 'https://localhost:7000',
  api: {
    auth: '/api/auth', customer: '/api/customers', product: '/api/products',
    riskQuote: '/api/riskquotes', policy: '/api/policies', claim: '/api/claims', surveyor: '/api/surveyors'
  }
};
