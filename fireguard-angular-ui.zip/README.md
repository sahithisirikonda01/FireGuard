# FireGuard Angular UI

Angular standalone frontend for the FireGuard wildfire insurance system.

## Run
1. `npm install`
2. Update `src/environments/environment.ts` with your Ocelot gateway URL.
3. Put the hero/product images under `src/assets/images/` if desired.
4. `ng serve`

## Backend contract
The frontend uses only the supplied AuthAPI, CustomerAPI, ProductAPI, RiskQuoteAPI, PolicyAPI and ClaimAPI flows. Angular calls the Ocelot gateway, not internal service URLs.

## Important
- Product endpoints are configured as `/api/products`, `/api/products/:id`, `/api/products/:id/activate`, `/api/products/:id/deactivate`. If your already-implemented ProductAPI uses different route names, change only `product.service.ts`.
- The exact API response property names should match the backend DTOs. The models mirror the backend contract supplied for Auth, Customer, RiskQuote, Policy and Claim.
- No service-to-service keys are stored in Angular.
- Colors are restricted to the seven approved FireGuard colors.
