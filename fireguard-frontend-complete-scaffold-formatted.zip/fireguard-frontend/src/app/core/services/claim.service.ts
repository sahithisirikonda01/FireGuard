import {
Injectable,inject
}
 from '@angular/core';
import {
ApiService
}
 from './api.service';
import {
Claim,CreateClaimRequest,DocumentItem,Surveyor
}
 from '../models/claim/claim.models';
 @Injectable({
providedIn:'root'
}
) export class Claim.ServiceService{
private api=inject(ApiService);
getMine(){
return this.api.get<Claim[]>('/claims/my')
}
;
getAll(){
return this.api.get<Claim[]>('/claims/admin/all')
}
;
getPending(){
return this.api.get<Claim[]>('/claims/admin/pending')
}
;
getById(id:number){
return this.api.get<Claim>('/claims/'+id)
}
;
getSurveyorClaims(){
return this.api.get<Claim[]>('/claims/surveyor/my')
}
;
assign(id:number,s:number){
return this.api.put('/claims/'+id+'/assign',{
surveyorId:s
}
)
}
;
start(id:number){
return this.api.put('/claims/'+id+'/start-investigation',{

}
)
}
;
report(id:number,x:unknown){
return this.api.put('/claims/'+id+'/survey-report',x)
}
;
decision(id:number,x:unknown){
return this.api.put('/claims/'+id+'/decision',x)
}
;
pay(id:number){
return this.api.post('/claims/'+id+'/payment',{

}
)
}
;
create(x:CreateClaimRequest){
return this.api.post<Claim>('/claims',x)
}
;
docs(id:number){
return this.api.get<DocumentItem[]>('/claims/'+id+'/documents')
}
;
upload(id:number,f:File,type:string){
const x=new FormData();
x.append('file',f);
x.append('documentType',type);
return this.api.upload('/claims/'+id+'/documents',x)
}
;
pendingSurveyors(){
return this.api.get<Surveyor[]>('/surveyors/pending')
}
;
approvedSurveyors(){
return this.api.get<Surveyor[]>('/surveyors/approved')
}
;
approveSurveyor(id:string){
return this.api.put('/surveyors/'+id+'/approve',{

}
)
}
;
rejectSurveyor(id:string){
return this.api.put('/surveyors/'+id+'/reject',{

}
)
}
;

}
