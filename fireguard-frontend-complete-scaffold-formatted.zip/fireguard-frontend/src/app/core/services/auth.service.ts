import {
Injectable,computed,inject,signal
}
 from '@angular/core';
import {
Router
}
 from '@angular/router';
import {
tap,finalize,of,catchError
}
 from 'rxjs';
import {
ApiService
}
 from './api.service';
import {
StorageService
}
 from './storage.service';
import {
LoginRequest,LoginResponse,UserProfile,UserRole,CustomerRegisterRequest,SurveyorRegisterRequest
}
 from '../models/auth/auth.models';
 @Injectable({
providedIn:'root'
}
) export class AuthService{
private api=inject(ApiService);
private store=inject(StorageService);
private router=inject(Router);
user=signal<UserProfile|null>(this.store.getUser<UserProfile>());
loading=signal(false);
isLoggedIn=computed(()=>!!this.store.get('fg_token'));
role=computed<UserRole|null>(()=>this.user()?.role??null);
login(x:LoginRequest){
this.loading.set(true);
return this.api.post<LoginResponse>('/auth/login',x).pipe(tap(r=>{
const u={
userId:r.userId,email:r.email,role:r.role,isActive:true
}
;
this.store.set('fg_token',r.token);
this.store.set('fg_refresh_token',r.refreshToken);
this.store.setUser(u);
this.user.set(u)
}
),finalize(()=>this.loading.set(false)))
}
registerCustomer(x:CustomerRegisterRequest){
return this.api.post('/auth/register/customer',x)
}
registerSurveyor(x:SurveyorRegisterRequest){
return this.api.post('/auth/register/surveyor',x)
}
loadProfile(){
if(!this.isLoggedIn())return of(null);
return this.api.get<UserProfile>('/auth/profile').pipe(tap(u=>{
this.user.set(u);
this.store.setUser(u)
}
),catchError(()=>{
this.logout(false);
return of(null)
}
))
}
logout(redirect=true){
this.store.clear();
this.user.set(null);
if(redirect)this.router.navigate(['/login'])
}
redirectAfterLogin(){
const r=this.role();
this.router.navigate([r==='Admin'?'/admin/dashboard':r==='Surveyor'?'/surveyor/dashboard':'/customer/dashboard'])
}

}
