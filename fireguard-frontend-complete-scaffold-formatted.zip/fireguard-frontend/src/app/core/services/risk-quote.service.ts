import {
Injectable,inject
}
 from '@angular/core';
import {
ApiService
}
 from './api.service';
import {
CreateQuoteRequest,Quote
}
 from '../models/quote/quote.models';
 @Injectable({
providedIn:'root'
}
) export class RiskQuote.ServiceService{
private api=inject(ApiService);
create(x:CreateQuoteRequest){
return this.api.post<Quote>('/riskquotes',x)
}
;
getMine(){
return this.api.get<Quote[]>('/riskquotes/my')
}
;
getById(id:number){
return this.api.get<Quote>('/riskquotes/'+id)
}
;
getPending(){
return this.api.get<Quote[]>('/riskquotes/admin/pending')
}
;
approve(id:number){
return this.api.put('/riskquotes/admin/'+id+'/approve',{

}
)
}
;
reject(id:number,remarks:string){
return this.api.put('/riskquotes/admin/'+id+'/reject',{
remarks
}
)
}
;

}
