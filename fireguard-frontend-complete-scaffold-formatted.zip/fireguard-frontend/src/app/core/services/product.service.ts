import {
Injectable,inject
}
 from '@angular/core';
import {
ApiService
}
 from './api.service';
import {
Product
}
 from '../models/product/product.models';
 @Injectable({
providedIn:'root'
}
) export class Product.ServiceService{
private api=inject(ApiService);
getAll(){
return this.api.get<Product[]>('/products')
}
;
getById(id:number){
return this.api.get<Product>('/products/'+id)
}
;

}
