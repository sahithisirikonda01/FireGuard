import {
Injectable,inject
}
 from '@angular/core';
import {
ApiService
}
 from './api.service';
import {
Customer
}
 from '../models/customer/customer.models';
 @Injectable({
providedIn:'root'
}
) export class Customer.ServiceService{
private api=inject(ApiService);
getMyProfile(){
return this.api.get<Customer>('/customers/me')
}
;

}
