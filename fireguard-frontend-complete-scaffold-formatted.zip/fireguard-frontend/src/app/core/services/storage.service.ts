import {
Injectable
}
 from '@angular/core';
 @Injectable({
providedIn:'root'
}
) export class StorageService{
set(k:string,v:string){
sessionStorage.setItem(k,v)
}
 get(k:string){
return sessionStorage.getItem(k)
}
 remove(k:string){
sessionStorage.removeItem(k)
}
 clear(){
sessionStorage.clear()
}
 setUser(v:unknown){
this.set('fg_user',JSON.stringify(v))
}
 getUser<T>():T|null{
const x=this.get('fg_user');
return x?JSON.parse(x):null
}

}
