import {
Injectable,signal
}
 from '@angular/core';
@Injectable({
providedIn:'root'
}
)export class NotificationService{
message=signal('');
error=signal('');
success(x:string){
this.error.set('');
this.message.set(x)
}
fail(x:string){
this.message.set('');
this.error.set(x)
}
clear(){
this.message.set('');
this.error.set('')
}

}
