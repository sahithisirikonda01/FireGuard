import {
Injectable,inject
}
 from '@angular/core';
import {
ApiService
}
 from './api.service';
import {
Policy,PaymentResponse
}
 from '../models/policy/policy.models';
 @Injectable({
providedIn:'root'
}
) export class Policy.ServiceService{
private api=inject(ApiService);
getMine(){
return this.api.get<Policy[]>('/policies/my')
}
;
getAll(){
return this.api.get<Policy[]>('/policies/admin/all')
}
;
getById(id:number){
return this.api.get<Policy>('/policies/'+id)
}
;
create(quoteId:number){
return this.api.post<Policy>('/policies',{
quoteId
}
)
}
;
pay(id:number){
return this.api.post<PaymentResponse>('/policies/'+id+'/payment',{

}
)
}
;

}
