import {
Injectable,inject
}
 from '@angular/core';
import {
HttpClient,HttpParams
}
 from '@angular/common/http';
import {
environment
}
 from '../../../environments/environment';
 @Injectable({
providedIn:'root'
}
) export class ApiService{
private http=inject(HttpClient);
private base=environment.apiBaseUrl;
 get<T>(p:string,params?:Record<string,string|number|boolean>){
let q=new HttpParams();
Object.entries(params??{

}
).forEach(([k,v])=>q=q.set(k,String(v)));
return this.http.get<T>(this.base+p,{
params:q
}
)
}
 post<T>(p:string,b?:unknown){
return this.http.post<T>(this.base+p,b)
}
 put<T>(p:string,b?:unknown){
return this.http.put<T>(this.base+p,b)
}
 upload<T>(p:string,f:FormData){
return this.http.post<T>(this.base+p,f)
}
 
}
