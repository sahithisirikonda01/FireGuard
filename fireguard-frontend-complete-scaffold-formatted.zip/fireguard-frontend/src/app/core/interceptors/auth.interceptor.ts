import {
HttpInterceptorFn
}
 from '@angular/common/http';
import {
inject
}
 from '@angular/core';
import {
StorageService
}
 from '../services/storage.service';
export const authInterceptor:HttpInterceptorFn=(req,next)=>{
const t=inject(StorageService).get('fg_token');
return t&&!req.url.includes('/auth/login')&&!req.url.includes('/auth/register')?next(req.clone({
setHeaders:{
Authorization:'Bearer '+t
}

}
)):next(req)
}
;
