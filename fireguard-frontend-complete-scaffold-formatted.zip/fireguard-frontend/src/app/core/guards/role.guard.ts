import {
inject
}
 from '@angular/core';
import {
CanActivateFn,Router
}
 from '@angular/router';
import {
AuthService
}
 from '../services/auth.service';
import {
UserRole
}
 from '../models/auth/auth.models';
export const roleGuard=(roles:UserRole[]):CanActivateFn=>()=>{
const a=inject(AuthService),r=inject(Router);
if(!a.isLoggedIn())return r.createUrlTree(['/login']);
return roles.includes(a.role()!)?true:r.createUrlTree(['/unauthorized'])
}
;
