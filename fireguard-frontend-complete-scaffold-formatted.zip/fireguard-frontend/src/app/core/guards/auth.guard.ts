import {
inject
}
 from '@angular/core';
import {
CanActivateFn,Router
}
 from '@angular/router';
import {
AuthService
}
 from '../services/auth.service';
export const authGuard:CanActivateFn=()=>{
const a=inject(AuthService);
const r=inject(Router);
return a.isLoggedIn()?true:r.createUrlTree(['/login'],{
queryParams:{
returnUrl:location.pathname
}

}
)
}
;
