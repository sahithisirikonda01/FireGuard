export type PolicyStatus='PendingPayment'|'Active'|'Expired'|'Cancelled';
 export type PaymentStatus='Pending'|'Paid'|'Failed';
 export interface Policy{
id:number;
policyNumber:string;
userId:string;
quoteId:number;
quoteNumber:string;
productId:number;
productName:string;
coverageAmount:number;
premiumAmount:number;
policyStatus:PolicyStatus;
paymentStatus:PaymentStatus;
createdAt:string;
startDate?:string;
endDate?:string
}
 export interface PaymentResponse{
policyId:number;
policyNumber:string;
amount:number;
paymentStatus:PaymentStatus;
policyStatus:PolicyStatus;
startDate?:string;
endDate?:string;
message:string
}
