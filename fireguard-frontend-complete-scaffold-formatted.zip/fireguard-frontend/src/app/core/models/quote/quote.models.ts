export type RiskLevel='Low'|'Medium'|'High'|'VeryHigh';
 export type QuoteStatus='PendingReview'|'Approved'|'Rejected'|'Expired';
 export interface CreateQuoteRequest{
productId:number;
propertyValue:number;
landArea:number;
constructionType:string;
roofType:string;
propertyAge:number;
forestDistance:number;
vegetationLevel:string;
hasSmokeDetector:boolean;
hasFireExtinguisher:boolean
}
 export interface Quote{
id:number;
quoteNumber:string;
userId:string;
productId:number;
productName:string;
riskScore:number;
riskLevel:RiskLevel;
finalPremium:number;
coverageAmount:number;
status:QuoteStatus;
expiryDate:string
}
