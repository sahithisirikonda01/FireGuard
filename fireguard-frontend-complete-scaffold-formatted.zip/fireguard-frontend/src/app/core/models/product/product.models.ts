export interface Product{
id:number;
code:string;
name:string;
description:string;
basePremium:number;
coverageLimit?:number;
isActive:boolean
}
 export interface PublicCategory{
id:string;
name:string;
description:string;
subs:{
name:string;
description:string;
covers:string[]
}
[]
}
