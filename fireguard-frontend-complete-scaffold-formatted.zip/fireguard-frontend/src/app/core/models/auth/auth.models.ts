export type UserRole='Customer'|'Admin'|'Surveyor';
 export interface LoginRequest{
email:string;
password:string
}
 export interface LoginResponse{
token:string;
refreshToken:string;
userId:string;
email:string;
role:UserRole;
expiresAt?:string
}
 export interface UserProfile{
userId:string;
email:string;
username?:string;
role:UserRole;
isActive:boolean
}
 export interface CustomerRegisterRequest{
fullName:string;
email:string;
phone:string;
address:string;
password:string
}
 export interface SurveyorRegisterRequest{
fullName:string;
email:string;
phone:string;
address:string;
qualification:string;
licenseNumber:string;
experienceYears:number;
password:string
}
