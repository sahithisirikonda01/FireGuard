export type ClaimStatus='PendingAssessment'|'Assigned'|'UnderInvestigation'|'SurveySubmitted'|'Approved'|'Rejected'|'Completed';
 export interface Claim{
id:number;
claimNumber:string;
userId:string;
policyId:number;
policyNumber:string;
productName:string;
incidentDescription:string;
incidentDate:string;
incidentLocation:string;
estimatedLossAmount:number;
surveyorId?:number;
surveyorName?:string;
surveyorReport?:string;
recommendedAmount?:number;
approvedAmount?:number;
adminRemarks?:string;
status:ClaimStatus;
claimPaymentStatus:'Pending'|'Paid'
}
 export interface CreateClaimRequest{
policyId:number;
incidentDescription:string;
incidentDate:string;
incidentLocation:string;
estimatedLossAmount:number
}
 export interface DocumentItem{
id:number;
claimId:number;
fileName:string;
contentType:string;
fileSize:number;
documentType:string;
uploadedByUserId:string;
uploadedAt:string
}
 export interface Surveyor{
id:number;
userId:string;
fullName:string;
email:string;
phone:string;
qualification:string;
licenseNumber:string;
experienceYears:number;
status:string
}
