import {
Component,input
}
 from '@angular/core';
@Component({
selector:'fg-status',standalone:true,templateUrl: './status-badge.component.html'
}
)export class StatusBadgeComponent{
value=input('Status')
}
