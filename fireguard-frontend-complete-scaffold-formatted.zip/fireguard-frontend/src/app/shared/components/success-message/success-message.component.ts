import {
Component,input,output
}
 from '@angular/core';
@Component({
selector:'fg-success-message',standalone:true,templateUrl: './success-message.component.html'
}
)export class SuccessMessageComponent{
title=input('Success Message');
actionText=input('Open');
action=output<void>()
}
