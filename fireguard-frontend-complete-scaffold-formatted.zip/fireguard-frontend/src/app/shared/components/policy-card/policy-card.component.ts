import {
Component,input,output
}
 from '@angular/core';
@Component({
selector:'fg-policy-card',standalone:true,templateUrl: './policy-card.component.html'
}
)export class PolicyCardComponent{
title=input('Policy Card');
actionText=input('Open');
action=output<void>()
}
