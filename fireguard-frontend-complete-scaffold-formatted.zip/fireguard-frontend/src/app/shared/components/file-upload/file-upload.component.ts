import {
Component,input,output
}
 from '@angular/core';
@Component({
selector:'fg-file-upload',standalone:true,templateUrl: './file-upload.component.html'
}
)export class FileUploadComponent{
title=input('File Upload');
actionText=input('Open');
action=output<void>()
}
