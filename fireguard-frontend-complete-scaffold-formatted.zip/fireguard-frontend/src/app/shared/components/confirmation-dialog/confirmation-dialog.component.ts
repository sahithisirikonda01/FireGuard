import {
Component,input,output
}
 from '@angular/core';
@Component({
selector:'fg-confirmation-dialog',standalone:true,templateUrl: './confirmation-dialog.component.html'
}
)export class ConfirmationDialogComponent{
title=input('Confirmation Dialog');
actionText=input('Open');
action=output<void>()
}
