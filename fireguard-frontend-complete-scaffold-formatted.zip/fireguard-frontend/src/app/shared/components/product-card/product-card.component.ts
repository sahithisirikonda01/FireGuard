import {
Component,input,output
}
 from '@angular/core';
@Component({
selector:'fg-product-card',standalone:true,templateUrl: './product-card.component.html'
}
)export class ProductCardComponent{
title=input('Product Card');
actionText=input('Open');
action=output<void>()
}
