import {
Component,input,output
}
 from '@angular/core';
@Component({
selector:'fg-error-message',standalone:true,templateUrl: './error-message.component.html'
}
)export class ErrorMessageComponent{
title=input('Error Message');
actionText=input('Open');
action=output<void>()
}
