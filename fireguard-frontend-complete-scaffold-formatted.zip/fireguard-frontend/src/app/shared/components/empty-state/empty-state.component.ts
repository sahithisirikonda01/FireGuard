import {
Component,input,output
}
 from '@angular/core';
@Component({
selector:'fg-empty-state',standalone:true,templateUrl: './empty-state.component.html'
}
)export class EmptyStateComponent{
title=input('Empty State');
actionText=input('Open');
action=output<void>()
}
