import {
Component,input,output
}
 from '@angular/core';
@Component({
selector:'fg-claim-card',standalone:true,templateUrl: './claim-card.component.html'
}
)export class ClaimCardComponent{
title=input('Claim Card');
actionText=input('Open');
action=output<void>()
}
