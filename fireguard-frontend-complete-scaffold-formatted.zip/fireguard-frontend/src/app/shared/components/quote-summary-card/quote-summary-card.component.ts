import {
Component,input,output
}
 from '@angular/core';
@Component({
selector:'fg-quote-summary-card',standalone:true,templateUrl: './quote-summary-card.component.html'
}
)export class QuoteSummaryCardComponent{
title=input('Quote Summary Card');
actionText=input('Open');
action=output<void>()
}
