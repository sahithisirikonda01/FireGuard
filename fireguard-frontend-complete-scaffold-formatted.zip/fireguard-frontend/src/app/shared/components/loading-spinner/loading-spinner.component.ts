import {
Component,input
}
 from '@angular/core';
@Component({
selector:'fg-loading',standalone:true,templateUrl: './loading-spinner.component.html'
}
)export class LoadingSpinnerComponent{
message=input('Loading...')
}
