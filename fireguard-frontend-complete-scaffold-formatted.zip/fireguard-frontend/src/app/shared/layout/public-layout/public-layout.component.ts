import {
Component,inject
}
 from '@angular/core';
import {
Router,RouterLink,RouterLinkActive,RouterOutlet
}
 from '@angular/router';
import {
AuthService
}
 from '../../core/services/auth.service';
@Component({
selector:'fg-public-layout',standalone:true,imports:[RouterOutlet,RouterLink,RouterLinkActive],templateUrl: './public-layout.component.html'
}
)export class PublicLayoutComponent{
private a=inject(AuthService);
logout(){
this.a.logout()
}

}
