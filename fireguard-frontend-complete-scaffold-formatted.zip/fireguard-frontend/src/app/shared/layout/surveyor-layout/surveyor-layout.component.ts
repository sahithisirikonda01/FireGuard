import {
Component,inject
}
 from '@angular/core';
import {
Router,RouterLink,RouterLinkActive,RouterOutlet
}
 from '@angular/router';
import {
AuthService
}
 from '../../core/services/auth.service';
@Component({
selector:'fg-surveyor-layout',standalone:true,imports:[RouterOutlet,RouterLink,RouterLinkActive],templateUrl: './surveyor-layout.component.html'
}
)export class SurveyorLayoutComponent{
private a=inject(AuthService);
logout(){
this.a.logout()
}

}
