import {
Component,inject
}
 from '@angular/core';
import {
Router,RouterLink,RouterLinkActive,RouterOutlet
}
 from '@angular/router';
import {
AuthService
}
 from '../../core/services/auth.service';
@Component({
selector:'fg-admin-layout',standalone:true,imports:[RouterOutlet,RouterLink,RouterLinkActive],templateUrl: './admin-layout.component.html'
}
)export class AdminLayoutComponent{
private a=inject(AuthService);
logout(){
this.a.logout()
}

}
