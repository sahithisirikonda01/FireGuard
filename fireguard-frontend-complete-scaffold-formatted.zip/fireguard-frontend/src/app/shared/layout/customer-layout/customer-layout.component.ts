import {
Component,inject
}
 from '@angular/core';
import {
Router,RouterLink,RouterLinkActive,RouterOutlet
}
 from '@angular/router';
import {
AuthService
}
 from '../../core/services/auth.service';
@Component({
selector:'fg-customer-layout',standalone:true,imports:[RouterOutlet,RouterLink,RouterLinkActive],templateUrl: './customer-layout.component.html'
}
)export class CustomerLayoutComponent{
private a=inject(AuthService);
logout(){
this.a.logout()
}

}
