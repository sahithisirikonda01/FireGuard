import {
ApplicationConfig
}
from'@angular/core';
import{
provideRouter,withInMemoryScrolling,withPreloading,PreloadAllModules
}
from'@angular/router';
import{
provideHttpClient,withInterceptors
}
from'@angular/common/http';
import{
routes
}
from'./app.routes';
import{
authInterceptor
}
from'./core/interceptors/auth.interceptor';
export const appConfig:ApplicationConfig={
providers:[provideRouter(routes,withPreloading(PreloadAllModules),withInMemoryScrolling({
scrollPositionRestoration:'enabled'
}
)),provideHttpClient(withInterceptors([authInterceptor]))]
}
;
