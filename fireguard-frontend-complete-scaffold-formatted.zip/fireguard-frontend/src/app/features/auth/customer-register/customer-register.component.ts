import {
Component,inject,signal
}
 from '@angular/core';
import {
FormBuilder,ReactiveFormsModule,Validators
}
 from '@angular/forms';
import {
Router,RouterLink
}
 from '@angular/router';
import {
AuthService
}
 from '../../../core/services/auth.service';
@Component({
selector:'fg-customer-register',standalone:true,imports:[ReactiveFormsModule,RouterLink],templateUrl:'./customer-register.component.html'
}
)export class CustomerRegisterComponent{
private fb=inject(FormBuilder);
private a=inject(AuthService);
private r=inject(Router);
error=signal('');
form=this.fb.nonNullable.group({
fullName:['',[Validators.required]],email:['',[Validators.required,Validators.email]],phone:['',[Validators.required]],address:['',[Validators.required]],password:['',[Validators.required,Validators.minLength(8)]],confirm:['',[Validators.required]]
}
);
submit(){
const v=this.form.getRawValue();
if(this.form.invalid){
this.form.markAllAsTouched();
return
}
if(v.password!==v.confirm){
this.error.set('Passwords do not match.');
return
}
this.a.registerCustomer({
fullName:v.fullName,email:v.email,phone:v.phone,address:v.address,password:v.password
}
).subscribe({
next:()=>this.r.navigate(['/login']),error:e=>this.error.set(e?.error?.message??'Registration failed.')
}
)
}

}
