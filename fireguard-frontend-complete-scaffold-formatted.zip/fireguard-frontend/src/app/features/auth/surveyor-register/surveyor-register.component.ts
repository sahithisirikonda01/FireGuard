import {
Component,inject
}
 from '@angular/core';
import {
FormBuilder,ReactiveFormsModule,Validators
}
 from '@angular/forms';
import {
AuthService
}
 from '../../../core/services/auth.service';
@Component({
selector:'fg-surveyor-register',standalone:true,imports:[ReactiveFormsModule],templateUrl: './surveyor-register.component.html'
}
)export class SurveyorRegisterComponent{
private fb=inject(FormBuilder);
private a=inject(AuthService);
form=this.fb.nonNullable.group({
fullName:['',[Validators.required]],email:['',[Validators.required,Validators.email]],phone:['',[Validators.required]],address:['',[Validators.required]],qualification:['',[Validators.required]],licenseNumber:['',[Validators.required]],experienceYears:[0,[Validators.min(0),Validators.max(50)]],password:['',[Validators.required]]
}
);
submit(){
if(this.form.valid)this.a.registerSurveyor(this.form.getRawValue()).subscribe()
}

}
