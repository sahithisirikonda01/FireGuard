import {
Component,inject,signal
}
 from '@angular/core';
import {
FormBuilder,ReactiveFormsModule,Validators
}
 from '@angular/forms';
import {
RouterLink
}
 from '@angular/router';
import {
AuthService
}
 from '../../../core/services/auth.service';
@Component({
selector:'fg-login',standalone:true,imports:[ReactiveFormsModule,RouterLink],templateUrl:'./login.component.html'
}
)export class LoginComponent{
private fb=inject(FormBuilder);
auth=inject(AuthService);
error=signal('');
form=this.fb.nonNullable.group({
email:['',[Validators.required,Validators.email]],password:['',[Validators.required,Validators.minLength(6)]]
}
);
submit(){
this.error.set('');
if(this.form.invalid){
this.form.markAllAsTouched();
return
}
this.auth.login(this.form.getRawValue()).subscribe({
next:()=>this.auth.redirectAfterLogin(),error:e=>this.error.set(e?.error?.message??'Login failed. Check credentials or account approval.')
}
)
}

}
