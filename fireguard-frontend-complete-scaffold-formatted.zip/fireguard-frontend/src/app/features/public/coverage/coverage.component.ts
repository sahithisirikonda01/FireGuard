import {
Component,signal
}
 from '@angular/core';
import {
RouterLink
}
 from '@angular/router';
@Component({
selector:'fg-coverage',standalone:true,imports:[RouterLink],templateUrl:'./coverage.component.html'
}
)export class CoverageComponent{
cats=signal([{
id:'home',name:'Wildfire Home',subs:['Home Structure Insurance','Home Contents Insurance','Home + Contents Insurance','Temporary Living Expenses','Personal Property Protection']
}
,{
id:'farm',name:'Wildfire Farm & Agricultural',subs:['Farm Property Insurance','Farm Equipment Insurance','Crop & Plantation Insurance','Livestock Protection','Agricultural Storage Insurance']
}
,{
id:'business',name:'Wildfire Business',subs:['Commercial Property Insurance','Business Equipment Insurance','Business Interruption Insurance','Inventory Protection','Commercial Building Protection']
}
,{
id:'vehicle',name:'Wildfire Vehicle & Equipment',subs:['Personal Vehicle Insurance','Commercial Vehicle Insurance','Specialized Equipment Insurance','Fleet Protection','Mobile Equipment Protection']
}
,{
id:'community',name:'Wildfire Community & Property Liability',subs:['Property Owner Liability','Community Property Insurance','Shared Facility Protection','Third-Party Property Liability','Community Asset Protection']
}
])
}
