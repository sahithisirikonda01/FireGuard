import {
Component,signal
}
 from '@angular/core';
@Component({
selector:'fg-faq',standalone:true,templateUrl: './faq.component.html'
}
)export class FaqComponent{
faqs=signal([{
q:'How is premium calculated?',a:'RiskQuoteAPI applies configured risk rules.'
}
,{
q:'Can I claim without an active policy?',a:'No. ClaimAPI verifies the policy is active.'
}
,{
q:'What happens to high-risk quotes?',a:'High and Very High quotes go to Admin review.'
}
,{
q:'Who makes the final claim decision?',a:'Admin makes the final decision after the survey report.'
}
])
}
