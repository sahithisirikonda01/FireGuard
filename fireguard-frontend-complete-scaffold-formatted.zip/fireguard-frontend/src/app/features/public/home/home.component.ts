import {
Component
}
 from '@angular/core';
import {
RouterLink
}
 from '@angular/router';
@Component({
selector:'fg-home',standalone:true,imports:[RouterLink],templateUrl:'./home.component.html'
}
)export class HomeComponent{
cats=[{
id:'home',name:'Wildfire Home',description:'Residential property and household protection.'
}
,{
id:'farm',name:'Wildfire Farm & Agricultural',description:'Farm buildings, equipment and eligible agricultural losses.'
}
,{
id:'business',name:'Wildfire Business',description:'Commercial property, equipment and eligible interruption losses.'
}
,{
id:'vehicle',name:'Wildfire Vehicle & Equipment',description:'Eligible vehicle and mobile equipment protection.'
}
,{
id:'community',name:'Wildfire Community & Property Liability',description:'Eligible community property and selected liability protection.'
}
] 
}
