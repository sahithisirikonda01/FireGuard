import {
Component
}
 from '@angular/core';
@Component({
selector:'fg-about',standalone:true,templateUrl: './about.component.html'
}
)export class AboutComponent{

}
