import {
Component,inject,signal
}
from'@angular/core';
import {
ActivatedRoute,RouterLink
}
from'@angular/router';
import {
PolicyService
}
from'../../../core/services/policy.service';
@Component({
selector:'fg-policy-details',standalone:true,imports:[RouterLink],templateUrl: './policy-details.component.html'
}
)export class PolicyDetailsComponent{
private a=inject(PolicyService);
id=Number(inject(ActivatedRoute).snapshot.paramMap.get('id'));
p=signal<any>(null);
constructor(){
this.a.getById(this.id).subscribe(x=>this.p.set(x))
}

}
