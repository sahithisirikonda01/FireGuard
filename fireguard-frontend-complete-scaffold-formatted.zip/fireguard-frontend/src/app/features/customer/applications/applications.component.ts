import {
Component
}
 from '@angular/core';
@Component({
selector:'fg-customer-applications',standalone:true,templateUrl: './applications.component.html'
}
)export class ApplicationsComponent{

}
