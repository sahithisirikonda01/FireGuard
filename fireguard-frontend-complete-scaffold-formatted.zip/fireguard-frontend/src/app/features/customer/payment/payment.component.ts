import {
Component,inject,signal
}
from'@angular/core';
import{
ActivatedRoute,RouterLink
}
from'@angular/router';
import{
PolicyService
}
from'../../../core/services/policy.service';
@Component({
selector:'fg-payment',standalone:true,imports:[RouterLink],templateUrl: './payment.component.html'
}
)export class PaymentComponent{
private a=inject(PolicyService);
id=Number(inject(ActivatedRoute).snapshot.paramMap.get('policyId'));
success=signal('');
pay(){
this.a.pay(this.id).subscribe({
next:x=>this.success.set(x.message),error:e=>this.success.set(e?.error?.message??'Payment failed')
}
)
}

}
