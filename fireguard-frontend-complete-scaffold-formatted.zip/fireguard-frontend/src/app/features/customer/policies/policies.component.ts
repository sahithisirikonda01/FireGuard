import {
Component,inject,signal
}
 from '@angular/core';
import {
RouterLink
}
 from '@angular/router';
import {
PolicyService
}
 from '../../../core/services/policy.service';
import {
Policy
}
 from '../../../core/models/policy/policy.models';
@Component({
selector:'fg-policies',standalone:true,imports:[RouterLink],templateUrl: './policies.component.html'
}
)export class PoliciesComponent{
private api=inject(PolicyService);
policies=signal<Policy[]>([]);
constructor(){
this.api.getMine().subscribe(x=>this.policies.set(x))
}

}
