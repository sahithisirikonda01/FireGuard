import {
Component,inject,signal
}
from'@angular/core';
import {
ActivatedRoute,Router,RouterLink
}
from'@angular/router';
import {
RiskQuoteService
}
from'../../../core/services/risk-quote.service';
import {
PolicyService
}
from'../../../core/services/policy.service';
@Component({
selector:'fg-quote-details',standalone:true,imports:[RouterLink],templateUrl: './quote-details.component.html'
}
)export class QuoteDetailsComponent{
private a=inject(RiskQuoteService);
private p=inject(PolicyService);
private r=inject(Router);
id=Number(inject(ActivatedRoute).snapshot.paramMap.get('id'));
q=signal<any>(null);
constructor(){
this.a.getById(this.id).subscribe(x=>this.q.set(x))
}
accept(id:number){
this.p.create(id).subscribe({
next:x=>this.r.navigate(['/customer/payment',x.id]),error:e=>alert(e?.error?.message??'Policy creation failed')
}
)
}

}
