import {
Component,inject,signal
}
from'@angular/core';
import{
ActivatedRoute,RouterLink
}
from'@angular/router';
import{
ClaimService
}
from'../../../core/services/claim.service';
import{
Claim,DocumentItem
}
from'../../../core/models/claim/claim.models';
@Component({
selector:'fg-customer-claim-details',standalone:true,imports:[RouterLink],templateUrl: './claim-details.component.html'
}
)export class ClaimDetailsComponent{
private a=inject(ClaimService);
id=Number(inject(ActivatedRoute).snapshot.paramMap.get('id'));
c=signal<Claim|null>(null);
docs=signal<DocumentItem[]>([]);
constructor(){
this.reload()
}
reload(){
this.a.getById(this.id).subscribe(x=>this.c.set(x));
this.a.docs(this.id).subscribe(x=>this.docs.set(x))
}
upload(e:Event){
const f=(e.target as HTMLInputElement).files?.[0];
if(f)this.a.upload(this.id,f,'CustomerEvidence').subscribe({
next:()=>this.reload(),error:x=>alert(x?.error?.message??'Upload failed')
}
)
}

}
