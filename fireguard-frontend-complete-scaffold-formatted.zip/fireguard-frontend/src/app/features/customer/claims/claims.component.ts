import {
Component,inject,signal
}
 from '@angular/core';
import {
RouterLink
}
 from '@angular/router';
import {
ClaimService
}
 from '../../../core/services/claim.service';
import {
Claim
}
 from '../../../core/models/claim/claim.models';
@Component({
selector:'fg-claims',standalone:true,imports:[RouterLink],templateUrl: './claims.component.html'
}
)export class ClaimsComponent{
private api=inject(ClaimService);
claims=signal<Claim[]>([]);
constructor(){
this.api.getMine().subscribe(x=>this.claims.set(x))
}

}
