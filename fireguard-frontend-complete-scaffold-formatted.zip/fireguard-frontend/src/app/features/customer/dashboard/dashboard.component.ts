import {
Component,inject,signal
}
 from '@angular/core';
import {
RouterLink
}
 from '@angular/router';
import {
forkJoin
}
 from 'rxjs';
import {
PolicyService
}
 from '../../../core/services/policy.service';
import {
RiskQuoteService
}
 from '../../../core/services/risk-quote.service';
import {
ClaimService
}
 from '../../../core/services/claim.service';
@Component({
selector:'fg-customer-dashboard',standalone:true,imports:[RouterLink],templateUrl: './dashboard.component.html'
}
)export class DashboardComponent{
private p=inject(PolicyService);
private q=inject(RiskQuoteService);
private c=inject(ClaimService);
active=signal(0);
pending=signal(0);
coverage=signal(0);
claims=signal(0);
constructor(){
forkJoin({
p:this.p.getMine(),q:this.q.getMine(),c:this.c.getMine()
}
).subscribe(x=>{
this.active.set(x.p.filter(a=>a.policyStatus==='Active').length);
this.coverage.set(x.p.filter(a=>a.policyStatus==='Active').reduce((s,a)=>s+a.coverageAmount,0));
this.pending.set(x.q.filter(a=>a.status==='PendingReview').length);
this.claims.set(x.c.length)
}
)
}

}
