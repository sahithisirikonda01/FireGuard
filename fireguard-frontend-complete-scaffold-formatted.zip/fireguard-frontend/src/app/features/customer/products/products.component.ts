import {
Component,inject,signal
}
 from '@angular/core';
import {
Router
}
 from '@angular/router';
import {
ProductService
}
 from '../../../core/services/product.service';
import {
Product
}
 from '../../../core/models/product/product.models';
@Component({
selector:'fg-customer-products',standalone:true,templateUrl: './products.component.html'
}
)export class ProductsComponent{
private api=inject(ProductService);
private r=inject(Router);
products=signal<Product[]>([]);
constructor(){
this.api.getAll().subscribe(x=>this.products.set(x.filter(p=>p.isActive)))
}
choose(p:Product){
this.r.navigate(['/customer/quote'],{
queryParams:{
productId:p.id
}

}
)
}

}
