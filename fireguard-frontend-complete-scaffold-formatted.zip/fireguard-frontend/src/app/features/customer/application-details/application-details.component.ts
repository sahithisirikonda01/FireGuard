import {
Component
}
 from '@angular/core';
@Component({
selector:'fg-customer-application-details',standalone:true,templateUrl: './application-details.component.html'
}
)export class ApplicationDetailsComponent{

}
