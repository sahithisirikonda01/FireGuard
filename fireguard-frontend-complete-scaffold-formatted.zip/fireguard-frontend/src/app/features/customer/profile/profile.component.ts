import {
Component
}
 from '@angular/core';
@Component({
selector:'fg-customer-profile',standalone:true,templateUrl: './profile.component.html'
}
)export class CustomerProfileComponent{

}
