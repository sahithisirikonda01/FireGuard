import {
Component,inject,signal,ChangeDetectorRef
}
 from '@angular/core';
import {
FormBuilder,ReactiveFormsModule,Validators
}
 from '@angular/forms';
import {
Router
}
 from '@angular/router';
import {
ProductService
}
 from '../../../core/services/product.service';
import {
RiskQuoteService
}
 from '../../../core/services/risk-quote.service';
import {
Product
}
 from '../../../core/models/product/product.models';
@Component({
selector:'fg-get-quote',standalone:true,imports:[ReactiveFormsModule],templateUrl:'./get-quote.component.html'
}
)export class GetQuoteComponent{
private fb=inject(FormBuilder);
private ps=inject(ProductService);
private qs=inject(RiskQuoteService);
private r=inject(Router);
private cd=inject(ChangeDetectorRef);
products=signal<Product[]>([]);
error=signal('');
form=this.fb.nonNullable.group({
productId:[0,[Validators.required,Validators.min(1)]],propertyValue:[0,[Validators.required,Validators.min(1)]],landArea:[0,[Validators.required,Validators.min(1)]],constructionType:['Concrete',[Validators.required]],roofType:['Tile',[Validators.required]],propertyAge:[0,[Validators.min(0)]],forestDistance:[0,[Validators.required,Validators.min(0)]],vegetationLevel:['Medium',[Validators.required]],hasSmokeDetector:[true],hasFireExtinguisher:[true]
}
);
constructor(){
this.ps.getAll().subscribe({
next:x=>{
this.products.set(x.filter(p=>p.isActive));
this.cd.markForCheck()
}
,error:()=>this.error.set('Unable to load products')
}
)
}
submit(){
if(this.form.invalid){
this.form.markAllAsTouched();
return
}
this.qs.create(this.form.getRawValue()).subscribe({
next:q=>this.r.navigate(['/customer/quote',q.id]),error:e=>this.error.set(e?.error?.message??'Quote creation failed')
}
)
}

}
