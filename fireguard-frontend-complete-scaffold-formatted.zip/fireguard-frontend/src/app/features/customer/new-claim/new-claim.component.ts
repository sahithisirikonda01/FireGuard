import {
Component,inject,signal
}
 from '@angular/core';
import {
FormBuilder,ReactiveFormsModule,Validators
}
from'@angular/forms';
import {
RouterLink,Router
}
from'@angular/router';
import {
PolicyService
}
from'../../../core/services/policy.service';
import {
ClaimService
}
from'../../../core/services/claim.service';
import {
Policy
}
from'../../../core/models/policy/policy.models';
@Component({
selector:'fg-new-claim',standalone:true,imports:[ReactiveFormsModule,RouterLink],templateUrl:'./new-claim.component.html'
}
)export class NewClaimComponent{
private fb=inject(FormBuilder);
private p=inject(PolicyService);
private c=inject(ClaimService);
private r=inject(Router);
policies=signal<Policy[]>([]);
error=signal('');
form=this.fb.nonNullable.group({
policyId:[0,[Validators.required,Validators.min(1)]],incidentDate:['',[Validators.required]],incidentDescription:['',[Validators.required,Validators.maxLength(2000)]],incidentLocation:['',[Validators.required,Validators.maxLength(500)]],estimatedLossAmount:[0,[Validators.required,Validators.min(0)]]
}
);
constructor(){
this.p.getMine().subscribe(x=>this.policies.set(x.filter(a=>a.policyStatus==='Active')))
}
submit(){
if(this.form.invalid){
this.form.markAllAsTouched();
return
}
this.c.create(this.form.getRawValue()).subscribe({
next:x=>this.r.navigate(['/customer/claims',x.id]),error:e=>this.error.set(e?.error?.message??'Claim creation failed')
}
)
}

}
