import {
Component,inject
}
from'@angular/core';
import{
FormBuilder,ReactiveFormsModule,Validators
}
from'@angular/forms';
import{
ActivatedRoute,Router,RouterLink
}
from'@angular/router';
import{
ClaimService
}
from'../../../core/services/claim.service';
@Component({
selector:'fg-survey-report',standalone:true,imports:[ReactiveFormsModule,RouterLink],templateUrl: './survey-report.component.html'
}
)export class SurveyReportComponent{
private fb=inject(FormBuilder);
private a=inject(ClaimService);
private r=inject(Router);
id=Number(inject(ActivatedRoute).snapshot.paramMap.get('id'));
form=this.fb.nonNullable.group({
surveyorReport:['',[Validators.required]],recommendedAmount:[0,[Validators.required,Validators.min(0)]]
}
);
submit(){
if(this.form.invalid)return;
this.a.report(this.id,this.form.getRawValue()).subscribe({
next:()=>this.r.navigate(['/surveyor/claim',this.id])
}
)
}

}
