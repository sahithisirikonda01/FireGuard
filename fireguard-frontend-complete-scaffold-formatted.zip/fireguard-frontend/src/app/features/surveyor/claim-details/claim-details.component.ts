import {
Component,inject,signal
}
from'@angular/core';
import{
ActivatedRoute,RouterLink
}
from'@angular/router';
import{
ClaimService
}
from'../../../core/services/claim.service';
@Component({
selector:'fg-surveyor-claim',standalone:true,imports:[RouterLink],templateUrl: './claim-details.component.html'
}
)export class ClaimDetailsComponent{
private a=inject(ClaimService);
id=Number(inject(ActivatedRoute).snapshot.paramMap.get('id'));
c=signal<any>(null);
constructor(){
this.a.getById(this.id).subscribe(x=>this.c.set(x))
}
start(){
this.a.start(this.id).subscribe({
next:()=>this.a.getById(this.id).subscribe(x=>this.c.set(x)),error:e=>alert(e?.error?.message??'Unable to start')
}
)
}
upload(e:Event){
const f=(e.target as HTMLInputElement).files?.[0];
if(f)this.a.upload(this.id,f,'SurveyorEvidence').subscribe()
}

}
