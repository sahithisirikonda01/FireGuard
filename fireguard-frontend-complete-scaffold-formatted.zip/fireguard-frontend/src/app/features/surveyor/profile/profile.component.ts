import {
Component
}
 from '@angular/core';
@Component({
selector:'fg-surveyor-profile',standalone:true,templateUrl: './profile.component.html'
}
)export class SurveyorProfileComponent{

}
