import {
Component
}
 from '@angular/core';
@Component({
selector:'fg-surveyor-my-surveys',standalone:true,templateUrl: './my-surveys.component.html'
}
)export class MySurveysComponent{

}
