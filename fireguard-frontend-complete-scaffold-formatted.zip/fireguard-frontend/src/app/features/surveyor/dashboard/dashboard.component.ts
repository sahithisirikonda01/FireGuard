import {
Component,inject,signal
}
from'@angular/core';
import{
RouterLink
}
from'@angular/router';
import{
ClaimService
}
from'../../../core/services/claim.service';
@Component({
selector:'fg-surveyor-dashboard',standalone:true,imports:[RouterLink],templateUrl: './dashboard.component.html'
}
)export class DashboardComponent{
private a=inject(ClaimService);
assigned=signal(0);
progress=signal(0);
submitted=signal(0);
completed=signal(0);
constructor(){
this.a.getSurveyorClaims().subscribe(x=>{
this.assigned.set(x.filter(c=>c.status==='Assigned').length);
this.progress.set(x.filter(c=>c.status==='UnderInvestigation').length);
this.submitted.set(x.filter(c=>c.status==='SurveySubmitted').length);
this.completed.set(x.filter(c=>c.status==='Completed').length)
}
)
}

}
