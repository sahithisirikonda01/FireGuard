import {
Component,inject,signal
}
from'@angular/core';
import{
RouterLink
}
from'@angular/router';
import{
ClaimService
}
from'../../../core/services/claim.service';
import{
Claim
}
from'../../../core/models/claim/claim.models';
@Component({
selector:'fg-assigned',standalone:true,imports:[RouterLink],templateUrl: './assigned-claims.component.html'
}
)export class AssignedClaimsComponent{
private a=inject(ClaimService);
claims=signal<Claim[]>([]);
constructor(){
this.a.getSurveyorClaims().subscribe(x=>this.claims.set(x))
}

}
