import {
Component
}
 from '@angular/core';
@Component({
selector:'fg-surveyor-reports',standalone:true,templateUrl: './reports.component.html'
}
)export class ReportsComponent{

}
