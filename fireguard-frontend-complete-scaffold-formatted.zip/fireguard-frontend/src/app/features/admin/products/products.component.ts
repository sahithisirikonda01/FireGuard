import {
Component
}
 from '@angular/core';
@Component({
selector:'fg-admin-products',standalone:true,templateUrl: './products.component.html'
}
)export class AdminProductsComponent{

}
