import {
Component,inject,signal
}
from'@angular/core';
import{
RouterLink
}
from'@angular/router';
import{
forkJoin
}
from'rxjs';
import{
PolicyService
}
from'../../../core/services/policy.service';
import{
ClaimService
}
from'../../../core/services/claim.service';
import{
RiskQuoteService
}
from'../../../core/services/risk-quote.service';
@Component({
selector:'fg-admin-dashboard',standalone:true,imports:[RouterLink],templateUrl: './dashboard.component.html'
}
)export class DashboardComponent{
private pApi=inject(PolicyService);
private cApi=inject(ClaimService);
private qApi=inject(RiskQuoteService);
p=signal(0);
c=signal(0);
q=signal(0);
s=signal(0);
constructor(){
forkJoin({
p:this.pApi.getAll(),c:this.cApi.getAll(),q:this.qApi.getPending(),s:this.cApi.pendingSurveyors()
}
).subscribe(x=>{
this.p.set(x.p.length);
this.c.set(x.c.length);
this.q.set(x.q.length);
this.s.set(x.s.length)
}
)
}

}
