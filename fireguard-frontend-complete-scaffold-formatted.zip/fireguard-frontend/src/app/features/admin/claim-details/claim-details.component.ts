import {
Component,inject,signal
}
from'@angular/core';
import{
ActivatedRoute,RouterLink
}
from'@angular/router';
import{
ClaimService
}
from'../../../core/services/claim.service';
@Component({
selector:'fg-admin-claim',standalone:true,imports:[RouterLink],templateUrl: './claim-details.component.html'
}
)export class ClaimDetailsComponent{
private a=inject(ClaimService);
id=Number(inject(ActivatedRoute).snapshot.paramMap.get('id'));
c=signal<any>(null);
constructor(){
this.load()
}
load(){
this.a.getById(this.id).subscribe(x=>this.c.set(x))
}
decide(ok:boolean){
const remarks=ok?'Approved after survey review.':prompt('Reason')||'';
if(!remarks)return;
this.a.decision(this.id,{
approved:ok,remarks,approvedAmount:ok?this.c()?.recommendedAmount:undefined
}
).subscribe(()=>this.load())
}
pay(){
this.a.pay(this.id).subscribe(()=>this.load())
}

}
