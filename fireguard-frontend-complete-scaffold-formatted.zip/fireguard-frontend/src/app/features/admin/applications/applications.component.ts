import {
Component
}
 from '@angular/core';
@Component({
selector:'fg-admin-applications',standalone:true,templateUrl: './applications.component.html'
}
)export class AdminApplicationsComponent{

}
