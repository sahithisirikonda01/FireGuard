import {
Component
}
 from '@angular/core';
@Component({
selector:'fg-admin-users',standalone:true,templateUrl: './users.component.html'
}
)export class UsersComponent{

}
