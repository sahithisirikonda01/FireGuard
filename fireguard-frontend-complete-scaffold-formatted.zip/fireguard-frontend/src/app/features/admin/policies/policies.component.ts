import {
Component
}
 from '@angular/core';
@Component({
selector:'fg-admin-policies',standalone:true,templateUrl: './policies.component.html'
}
)export class AdminPoliciesComponent{

}
