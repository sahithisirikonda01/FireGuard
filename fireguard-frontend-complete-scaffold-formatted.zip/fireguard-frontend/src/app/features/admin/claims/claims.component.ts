import {
Component,inject,signal
}
from'@angular/core';
import{
RouterLink
}
from'@angular/router';
import{
ClaimService
}
from'../../../core/services/claim.service';
@Component({
selector:'fg-admin-claims',standalone:true,imports:[RouterLink],templateUrl: './claims.component.html'
}
)export class ClaimsComponent{
private a=inject(ClaimService);
claims=signal<any[]>([]);
constructor(){
this.a.getAll().subscribe(x=>this.claims.set(x))
}

}
