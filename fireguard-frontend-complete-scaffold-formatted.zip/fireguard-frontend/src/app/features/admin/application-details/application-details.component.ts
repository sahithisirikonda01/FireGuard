import {
Component
}
 from '@angular/core';
@Component({
selector:'fg-admin-application-details',standalone:true,templateUrl: './application-details.component.html'
}
)export class AdminApplicationDetailsComponent{

}
