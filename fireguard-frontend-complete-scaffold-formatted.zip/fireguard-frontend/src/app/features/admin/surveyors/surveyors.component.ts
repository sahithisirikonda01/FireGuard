import {
Component,inject,signal
}
from'@angular/core';
import{
ClaimService
}
from'../../../core/services/claim.service';
import{
Surveyor
}
from'../../../core/models/claim/claim.models';
@Component({
selector:'fg-admin-surveyors',standalone:true,templateUrl: './surveyors.component.html'
}
)export class SurveyorsComponent{
private a=inject(ClaimService);
surveyors=signal<Surveyor[]>([]);
constructor(){
this.load()
}
load(){
this.a.pendingSurveyors().subscribe(x=>this.surveyors.set(x))
}
approve(s:Surveyor){
this.a.approveSurveyor(s.userId).subscribe(()=>this.load())
}
reject(s:Surveyor){
this.a.rejectSurveyor(s.userId).subscribe(()=>this.load())
}

}
