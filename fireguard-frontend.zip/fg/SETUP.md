# FireGuard frontend – setup (Windows, Angular 21.2.17)
1. ng new fireguard --style=css --routing=false --ssr=false --skip-tests
2. cd fireguard && npm i tailwindcss @tailwindcss/postcss postcss
3. Copy `.postcssrc.json` to the project root and the `src` folder over the generated `src` (overwrite).
4. Edit `src/app/core/config.ts` -> your Ocelot gateway URL.
5. ng serve
Roles expected from login: Customer / Admin / Surveyor.
