export interface Category { slug: string; name: string; code: string; desc: string; items: { name: string; covers: string }[]; }
const i = (name: string, covers: string) => ({ name, covers });
export const CATALOG: Category[] = [
  { slug: 'home', name: 'Wildfire Home Insurance', code: 'WILDFIRE_HOME', desc: 'Protect your house and belongings from wildfire damage.', items: [
    i('Home Structure Insurance', 'Dwelling, walls, roof and fixed structures'), i('Home Contents Insurance', 'Furniture, appliances and personal property'),
    i('Home + Contents Insurance', 'Building and belongings in one plan'), i('Rental Property Insurance', 'Landlord cover for let-out property'), i('High-Value Home Insurance', 'Higher limits for premium homes')] },
  { slug: 'farm', name: 'Wildfire Farm & Agriculture Insurance', code: 'WILDFIRE_FARM', desc: 'Cover for farms, crops and livelihoods.', items: [
    i('Farm Property Insurance', 'Farm buildings and structures'), i('Farm Equipment Insurance', 'Tractors, tools and machinery'), i('Crop Insurance', 'Standing crops and produce'),
    i('Orchard & Plantation Insurance', 'Trees, orchards and plantations'), i('Livestock & Farm Asset Insurance', 'Livestock, sheds and stored feed')] },
  { slug: 'business', name: 'Wildfire Business Insurance', code: 'WILDFIRE_BUSINESS', desc: 'Keep your business running after a wildfire.', items: [
    i('Commercial Property Insurance', 'Shops, offices and fittings'), i('Warehouse Insurance', 'Warehouse building and stored stock'), i('Factory & Industrial Insurance', 'Plant, factory and industrial units'),
    i('Business Equipment Insurance', 'Machinery and equipment'), i('Business Interruption Insurance', 'Lost income during shutdown')] },
  { slug: 'vehicle', name: 'Wildfire Vehicle & Transportation Insurance', code: 'WILDFIRE_VEHICLE', desc: 'Vehicles and transport assets damaged by wildfire.', items: [
    i('Private Vehicle Insurance', 'Cars and bikes'), i('Commercial Vehicle Insurance', 'Trucks and delivery vehicles'), i('Fleet Insurance', 'Multiple vehicles under one plan'),
    i('Agricultural Vehicle Insurance', 'Tractors and farm vehicles'), i('Specialized Equipment Insurance', 'Cranes, earth movers and special machines')] },
  { slug: 'community', name: 'Wildfire Community & Liability Insurance', code: 'WILDFIRE_COMMUNITY', desc: 'Shared property and liability for communities.', items: [
    i('Community Property Insurance', 'Shared community buildings'), i('Apartment & Housing Society Insurance', 'Common areas of housing societies'), i('Property Owner Liability Insurance', 'Third-party claims against owners'),
    i('Commercial Liability Insurance', 'Business liability for fire spread'), i('Community Infrastructure Insurance', 'Roads, utilities and shared assets')] },
];
