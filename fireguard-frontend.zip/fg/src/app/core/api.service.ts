import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { API } from './config';
@Injectable({ providedIn: 'root' })
export class Api {
  private http = inject(HttpClient);
  get<T>(url: string) { return this.http.get<T>(API + url); }
  post<T>(url: string, body: any = {}) { return this.http.post<T>(API + url, body); }
  send(method: string, url: string, body: any = {}) { return this.http.request(method, API + url, { body }); }
}
