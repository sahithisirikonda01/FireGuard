import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs';
import { API } from './config';
export interface Session { token: string; refresh?: string; role: string; email: string; }
const KEY = 'fg_session';
const ROLE_CLAIM = 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role';
@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient); private router = inject(Router);
  session = signal<Session | null>(JSON.parse(localStorage.getItem(KEY) ?? 'null'));
  isLoggedIn = computed(() => !!this.session());
  role = computed(() => this.session()?.role ?? '');
  login(body: { email: string; password: string }) {
    return this.http.post<any>(`${API}/api/auth/login`, body).pipe(tap(r => {
      const token = r.accessToken ?? r.token;
      let role = r.role;
      if (!role) { try { const p = JSON.parse(atob(token.split('.')[1])); role = p[ROLE_CLAIM] ?? p.role; } catch {} }
      const s: Session = { token, refresh: r.refreshToken, role: role ?? 'Customer', email: body.email };
      localStorage.setItem(KEY, JSON.stringify(s)); this.session.set(s);
    }));
  }
  registerCustomer(body: any) { return this.http.post(`${API}/api/auth/register/customer`, body); }
  homeFor(role = this.role()) { return role === 'Admin' ? '/app/admin/quotes' : role === 'Surveyor' ? '/app/surveyor/claims' : '/app/policies'; }
  logout() { localStorage.removeItem(KEY); this.session.set(null); this.router.navigate(['/login']); }
}
