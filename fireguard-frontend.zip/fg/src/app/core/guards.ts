import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth.service';
export const authGuard: CanActivateFn = (_r, state) => {
  const a = inject(AuthService), r = inject(Router);
  return a.isLoggedIn() ? true : r.createUrlTree(['/login'], { queryParams: { returnUrl: state.url } });
};
export const roleGuard = (roles: string[]): CanActivateFn => () => {
  const a = inject(AuthService), r = inject(Router);
  return roles.includes(a.role()) ? true : r.parseUrl(a.homeFor());
};
export const landingGuard: CanActivateFn = () => { const a = inject(AuthService); return inject(Router).parseUrl(a.homeFor()); };
