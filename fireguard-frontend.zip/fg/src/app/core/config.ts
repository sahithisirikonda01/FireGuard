// Ocelot gateway base URL - change to your gateway port
export const API = 'http://localhost:5000';
