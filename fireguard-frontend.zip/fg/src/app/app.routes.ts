import { Routes } from '@angular/router';
import { authGuard, landingGuard, roleGuard } from './core/guards';
const list = () => import('./pages/card-list').then(m => m.CardList);
export const routes: Routes = [
  { path: '', loadComponent: () => import('./pages/home').then(m => m.Home) },
  { path: 'category/:slug', loadComponent: () => import('./pages/category').then(m => m.CategoryPage) },
  { path: 'login', loadComponent: () => import('./pages/login').then(m => m.Login) },
  { path: 'register', loadComponent: () => import('./pages/register').then(m => m.Register) },
  { path: 'app', canActivate: [authGuard], loadComponent: () => import('./pages/shell').then(m => m.Shell), children: [
    { path: '', pathMatch: 'full', canActivate: [landingGuard], children: [] },
    { path: 'policies', canActivate: [roleGuard(['Customer'])], loadComponent: list, data: { title: 'My Policies', url: '/api/policies/my', titleKey: 'productName', sub: 'policyNumber', badge: 'policyStatus',
      fields: [['Coverage', 'coverageAmount'], ['Premium', 'premiumAmount'], ['Payment', 'paymentStatus'], ['Valid till', 'endDate']],
      actions: [{ label: 'Pay premium', method: 'POST', url: '/api/policies/{id}/payment', key: 'paymentStatus', in: ['Pending'] }] } },
    { path: 'quotes', canActivate: [roleGuard(['Customer'])], loadComponent: list, data: { title: 'My Quotes', url: '/api/riskquotes/my', titleKey: 'productName', sub: 'quoteNumber', badge: 'status',
      fields: [['Risk', 'riskLevel'], ['Premium', 'finalPremium'], ['Coverage', 'coverageAmount'], ['Expires', 'expiryDate']] } },
    { path: 'claims', canActivate: [roleGuard(['Customer'])], loadComponent: list, data: { title: 'My Claims', url: '/api/claims/my', titleKey: 'productName', sub: 'claimNumber', badge: 'status', cta: ['New claim', '/app/claims/new'],
      fields: [['Policy', 'policyNumber'], ['Estimated loss', 'estimatedLossAmount'], ['Approved', 'approvedAmount'], ['Payment', 'claimPaymentStatus']] } },
    { path: 'claims/new', canActivate: [roleGuard(['Customer'])], loadComponent: () => import('./pages/claim-form').then(m => m.ClaimForm) },
    { path: 'quote', canActivate: [roleGuard(['Customer'])], loadComponent: () => import('./pages/quote-form').then(m => m.QuoteForm) },
    { path: 'admin/quotes', canActivate: [roleGuard(['Admin'])], loadComponent: list, data: { title: 'Quotes for Review', url: '/api/riskquotes/admin/pending', titleKey: 'productName', sub: 'quoteNumber', badge: 'riskLevel',
      fields: [['Risk score', 'riskScore'], ['Premium', 'finalPremium'], ['Property value', 'propertyValue']],
      actions: [{ label: 'Approve', method: 'PUT', url: '/api/riskquotes/admin/{id}/approve' }, { label: 'Reject', method: 'PUT', url: '/api/riskquotes/admin/{id}/reject', ghost: true }] } },
    { path: 'admin/claims', canActivate: [roleGuard(['Admin'])], loadComponent: list, data: { title: 'All Claims', url: '/api/claims/admin/all', titleKey: 'claimNumber', sub: 'productName', badge: 'status',
      fields: [['Incident', 'incidentLocation'], ['Estimated loss', 'estimatedLossAmount'], ['Recommended', 'recommendedAmount']],
      actions: [{ label: 'Pay coverage', method: 'POST', url: '/api/claims/{id}/payment', key: 'status', in: ['Approved'] }] } },
    { path: 'admin/policies', canActivate: [roleGuard(['Admin'])], loadComponent: list, data: { title: 'All Policies', url: '/api/policies/admin/all', titleKey: 'productName', sub: 'policyNumber', badge: 'policyStatus',
      fields: [['Coverage', 'coverageAmount'], ['Premium', 'premiumAmount'], ['Start', 'startDate'], ['End', 'endDate']] } },
    { path: 'surveyor/claims', canActivate: [roleGuard(['Surveyor'])], loadComponent: list, data: { title: 'Assigned Claims', url: '/api/claims/surveyor/my', titleKey: 'claimNumber', sub: 'productName', badge: 'status',
      fields: [['Location', 'incidentLocation'], ['Incident date', 'incidentDate'], ['Estimated loss', 'estimatedLossAmount']],
      actions: [{ label: 'Start investigation', method: 'PUT', url: '/api/claims/{id}/start-investigation', key: 'status', in: ['Assigned'] }] } },
  ] },
  { path: '**', redirectTo: '' },
];
