import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { Router } from '@angular/router';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Api } from '../core/api.service';
@Component({
  selector: 'fg-quote-form', standalone: true, imports: [NgFor, NgIf, ReactiveFormsModule], changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
  <h1 class="text-3xl text-primary mb-6">Get a quote</h1>
  <div class="grid gap-6 lg:grid-cols-2">
  <form class="card grid grid-cols-2 gap-3" [formGroup]="f" (ngSubmit)="submit()">
    <label class="col-span-2 text-sm">Product<select class="inp" formControlName="productId"><option [ngValue]="0">Select…</option>
      <option *ngFor="let p of products()" [ngValue]="p.id">{{ p.productName }}</option></select></label>
    <label class="text-sm">Property value (₹)<input class="inp" type="number" formControlName="propertyValue"></label>
    <label class="text-sm">Land area (sq ft)<input class="inp" type="number" formControlName="landArea"></label>
    <label class="text-sm">Construction<select class="inp" formControlName="constructionType"><option>Good</option><option>Poor</option></select></label>
    <label class="text-sm">Roof<select class="inp" formControlName="roofType"><option>Metal</option><option>Tile</option><option>Concrete</option></select></label>
    <label class="text-sm">Property age (yrs)<input class="inp" type="number" formControlName="propertyAge"></label>
    <label class="text-sm">Forest distance (km)<input class="inp" type="number" formControlName="forestDistance"></label>
    <label class="text-sm">Vegetation<select class="inp" formControlName="vegetationLevel"><option>Low</option><option>Medium</option><option>High</option></select></label>
    <div class="text-sm space-y-1"><label class="block"><input type="checkbox" formControlName="hasSmokeDetector"> Smoke detector</label>
      <label class="block"><input type="checkbox" formControlName="hasFireExtinguisher"> Fire extinguisher</label></div>
    <p class="err col-span-2" *ngIf="f.touched && f.invalid">Fill all fields with valid values.</p>
    <p class="err col-span-2" *ngIf="msg()">{{ msg() }}</p>
    <button class="btn col-span-2">Calculate quote</button>
  </form>
  <div class="card" *ngIf="result() as q"><h3 class="text-xl text-primary">{{ q.quoteNumber }}</h3>
    <p class="mt-2">Risk: <b>{{ q.riskLevel }}</b> (score {{ q.riskScore }})</p><p>Premium: <b>₹{{ q.finalPremium }}</b></p>
    <p>Coverage: ₹{{ q.coverageAmount }}</p><p>Status: <b>{{ q.status }}</b></p>
    <button class="btn mt-4" *ngIf="q.status === 'Approved'" (click)="accept()">Accept &amp; pay</button>
    <p class="text-sm mt-3" *ngIf="q.status !== 'Approved'">Sent to admin for review. Track it under Quotes.</p></div></div>`
})
export class QuoteForm {
  private api = inject(Api); private router = inject(Router);
  products = signal<any[]>([]); result = signal<any>(null); msg = signal('');
  f = inject(FormBuilder).nonNullable.group({ productId: [0, [Validators.required, Validators.min(1)]], propertyValue: [0, [Validators.required, Validators.min(1)]],
    landArea: [0, [Validators.required, Validators.min(1)]], constructionType: ['Good'], roofType: ['Metal'], propertyAge: [0, [Validators.required, Validators.min(0)]],
    forestDistance: [0, [Validators.required, Validators.min(0)]], vegetationLevel: ['Low'], hasSmokeDetector: [true], hasFireExtinguisher: [true] });
  constructor() { this.api.get<any[]>('/api/products').subscribe(p => this.products.set(p)); }
  submit() {
    if (this.f.invalid) { this.f.markAllAsTouched(); return; }
    this.api.post('/api/riskquotes', this.f.getRawValue()).subscribe({ next: q => this.result.set(q), error: e => this.msg.set(e.error?.message ?? 'Quote failed') });
  }
  accept() {
    this.api.post<any>('/api/policies', { quoteId: this.result().id }).subscribe({
      next: p => this.api.post(`/api/policies/${p.id}/payment`).subscribe(() => this.router.navigate(['/app/policies'])),
      error: e => this.msg.set(e.error?.message ?? 'Could not create policy') });
  }
}
