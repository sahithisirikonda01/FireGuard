import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { map } from 'rxjs';
import { CATALOG } from '../core/catalog';
@Component({
  selector: 'fg-category', standalone: true, imports: [NgFor, NgIf, RouterLink], changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
  <div class="max-w-6xl mx-auto px-6 py-10" *ngIf="cat() as c">
    <a routerLink="/" class="text-primary">← All categories</a>
    <h1 class="text-4xl text-primary mt-3">{{ c.name }}</h1><p class="mt-2 text-gray-600">{{ c.desc }}</p>
    <div class="grid gap-5 md:grid-cols-2 lg:grid-cols-3 mt-8">
      <div class="card flex flex-col" *ngFor="let it of c.items">
        <h3 class="text-lg text-primary">{{ it.name }}</h3>
        <p class="text-xs uppercase text-gray-500 mt-3">What it covers</p><p class="text-sm">{{ it.covers }}</p>
        <a class="btn mt-auto self-start" [routerLink]="['/app/quote']" [queryParams]="{ category: c.slug, plan: it.name }">Explore</a>
      </div></div></div>`
})
export class CategoryPage {
  slug = toSignal(inject(ActivatedRoute).paramMap.pipe(map(p => p.get('slug'))));
  cat = computed(() => CATALOG.find(c => c.slug === this.slug()));
}
