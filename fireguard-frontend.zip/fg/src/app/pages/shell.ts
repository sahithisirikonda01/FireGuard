import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { NgFor } from '@angular/common';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../core/auth.service';
const NAV: Record<string, string[][]> = {
  Customer: [['Policies', 'policies'], ['Quotes', 'quotes'], ['Claims', 'claims'], ['Get a quote', 'quote']],
  Admin: [['Quotes', 'admin/quotes'], ['Claims', 'admin/claims'], ['Policies', 'admin/policies']],
  Surveyor: [['Assigned claims', 'surveyor/claims']] };
@Component({
  selector: 'fg-shell', standalone: true, imports: [NgFor, RouterLink, RouterLinkActive, RouterOutlet], changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
  <div class="min-h-screen md:flex">
    <aside class="bg-primary text-white md:w-60 p-5 flex md:flex-col gap-2 flex-wrap">
      <a routerLink="/" class="font-serif text-2xl mb-4 w-full">🔥 FireGuard</a>
      <a *ngFor="let n of nav()" [routerLink]="'/app/' + n[1]" routerLinkActive="bg-white/20" class="px-3 py-2 rounded-lg hover:bg-white/10">{{ n[0] }}</a>
      <div class="md:mt-auto text-xs opacity-80 w-full">{{ auth.session()?.email }} · {{ auth.role() }}</div>
      <button class="btn-o !text-white !border-white w-full" (click)="auth.logout()">Log out</button>
    </aside>
    <main class="flex-1 p-6 bg-warm-lighter"><router-outlet /></main>
  </div>`
})
export class Shell { auth = inject(AuthService); nav = computed(() => NAV[this.auth.role()] ?? []); }
