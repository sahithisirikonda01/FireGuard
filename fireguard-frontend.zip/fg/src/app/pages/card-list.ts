import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Api } from '../core/api.service';
@Component({
  selector: 'fg-card-list', standalone: true, imports: [NgFor, NgIf, RouterLink], changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
  <div class="flex items-center justify-between mb-6">
    <h1 class="text-3xl text-primary">{{ cfg.title }}</h1>
    <a *ngIf="cfg.cta" class="btn" [routerLink]="cfg.cta[1]">{{ cfg.cta[0] }}</a>
  </div>
  <p *ngIf="loading()" class="text-gray-500">Loading…</p>
  <p *ngIf="err()" class="err">{{ err() }}</p>
  <p *ngIf="!loading() && !err() && items().length === 0" class="card text-gray-500">Nothing here yet.</p>
  <div class="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
    <div class="card" *ngFor="let it of items()">
      <div class="flex justify-between items-start gap-2">
        <div><h3 class="text-lg text-primary">{{ it[cfg.titleKey] }}</h3><p class="text-xs text-gray-500">{{ it[cfg.sub] }}</p></div>
        <span class="text-xs font-semibold px-2.5 py-1 rounded-full" [class]="cls(it[cfg.badge])">{{ it[cfg.badge] }}</span>
      </div>
      <dl class="mt-4 grid grid-cols-2 gap-3 text-sm">
        <div *ngFor="let f of cfg.fields"><dt class="text-xs text-gray-500">{{ f[0] }}</dt><dd class="font-medium">{{ it[f[1]] ?? '—' }}</dd></div>
      </dl>
      <div class="mt-4 flex gap-2" *ngIf="cfg.actions">
        <ng-container *ngFor="let a of cfg.actions">
          <button *ngIf="show(a, it)" [class]="a.ghost ? 'btn-o' : 'btn'" (click)="act(a, it)">{{ a.label }}</button>
        </ng-container>
      </div>
    </div>
  </div>`
})
export class CardList {
  private api = inject(Api); cfg = inject(ActivatedRoute).snapshot.data as any;
  items = signal<any[]>([]); loading = signal(true); err = signal('');
  constructor() { this.load(); }
  load() {
    this.loading.set(true);
    this.api.get<any[]>(this.cfg.url).subscribe({
      next: d => { this.items.set(d); this.loading.set(false); },
      error: e => { this.err.set(e.error?.message ?? 'Could not load data'); this.loading.set(false); } });
  }
  show(a: any, it: any) { return !a.key || a.in.includes(it[a.key]); }
  act(a: any, it: any) { this.api.send(a.method, a.url.replace('{id}', it.id)).subscribe({ next: () => this.load(), error: e => this.err.set(e.error?.message ?? 'Action failed') }); }
  cls(s: string) {
    const v = (s ?? '').toLowerCase();
    if (/active|approved|completed|paid|low|medium/.test(v)) return 'bg-green-100 text-green-800';
    if (/reject|lapsed|expired|very|high/.test(v)) return 'bg-red-100 text-red-800';
    return 'bg-primary-100 text-primary';
  }
}
