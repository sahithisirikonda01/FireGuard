import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { NgIf } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../core/auth.service';
@Component({
  selector: 'fg-register', standalone: true, imports: [NgIf, ReactiveFormsModule, RouterLink], changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
  <div class="min-h-screen grid place-items-center bg-warm p-4"><form class="card w-full max-w-sm space-y-3" [formGroup]="f" (ngSubmit)="go()">
    <h1 class="text-3xl text-primary">Create your account</h1>
    <input class="inp" placeholder="Full name" formControlName="fullName">
    <input class="inp" type="email" placeholder="Email" formControlName="email">
    <input class="inp" placeholder="Phone (10 digits)" formControlName="phone">
    <input class="inp" type="password" placeholder="Password (min 8)" formControlName="password">
    <p class="err" *ngIf="f.touched && f.invalid">Please complete all fields correctly.</p>
    <p class="err" *ngIf="err()">{{ err() }}</p>
    <button class="btn w-full">Register</button>
    <p class="text-sm text-center">Have an account? <a routerLink="/login" class="text-primary font-semibold">Login</a></p></form></div>`
})
export class Register {
  private auth = inject(AuthService); private router = inject(Router);
  f = inject(FormBuilder).nonNullable.group({ fullName: ['', Validators.required], email: ['', [Validators.required, Validators.email]],
    phone: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]], password: ['', [Validators.required, Validators.minLength(8)]] });
  err = signal('');
  go() {
    if (this.f.invalid) { this.f.markAllAsTouched(); return; }
    this.auth.registerCustomer(this.f.getRawValue()).subscribe({ next: () => this.router.navigate(['/login']), error: e => this.err.set(e.error?.message ?? 'Registration failed') });
  }
}
