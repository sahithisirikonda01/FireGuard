import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { Router } from '@angular/router';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Api } from '../core/api.service';
@Component({
  selector: 'fg-claim-form', standalone: true, imports: [NgFor, NgIf, ReactiveFormsModule], changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
  <h1 class="text-3xl text-primary mb-6">File a claim</h1>
  <form class="card max-w-xl space-y-3" [formGroup]="f" (ngSubmit)="submit()">
    <select class="inp" formControlName="policyId"><option [ngValue]="0">Select active policy…</option>
      <option *ngFor="let p of policies()" [ngValue]="p.id">{{ p.policyNumber }} – {{ p.productName }}</option></select>
    <input class="inp" type="date" formControlName="incidentDate">
    <input class="inp" placeholder="Incident location" formControlName="incidentLocation">
    <input class="inp" type="number" placeholder="Estimated loss (₹)" formControlName="estimatedLossAmount">
    <textarea class="inp" rows="4" placeholder="What happened?" formControlName="incidentDescription"></textarea>
    <p class="err" *ngIf="f.touched && f.invalid">All fields are required.</p><p class="err" *ngIf="msg()">{{ msg() }}</p>
    <button class="btn">Submit claim</button></form>`
})
export class ClaimForm {
  private api = inject(Api); private router = inject(Router);
  policies = signal<any[]>([]); msg = signal('');
  f = inject(FormBuilder).nonNullable.group({ policyId: [0, Validators.min(1)], incidentDate: ['', Validators.required], incidentLocation: ['', Validators.required],
    estimatedLossAmount: [0, Validators.min(1)], incidentDescription: ['', [Validators.required, Validators.minLength(10)]] });
  constructor() { this.api.get<any[]>('/api/policies/my').subscribe(p => this.policies.set(p.filter(x => x.policyStatus === 'Active'))); }
  submit() {
    if (this.f.invalid) { this.f.markAllAsTouched(); return; }
    this.api.post('/api/claims', this.f.getRawValue()).subscribe({ next: () => this.router.navigate(['/app/claims']), error: e => this.msg.set(e.error?.message ?? 'Claim failed') });
  }
}
