import { ChangeDetectionStrategy, Component } from '@angular/core';
import { NgFor } from '@angular/common';
import { RouterLink } from '@angular/router';
import { CATALOG } from '../core/catalog';
@Component({
  selector: 'fg-home', standalone: true, imports: [NgFor, RouterLink], changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
  <header class="bg-primary text-white"><div class="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
    <span class="font-serif text-2xl">🔥 FireGuard</span>
    <nav class="flex gap-3"><a routerLink="/login" class="btn-o !text-white !border-white">Login</a><a routerLink="/register" class="btn !bg-fuchsia">Register</a></nav></div>
    <div class="max-w-6xl mx-auto px-6 pt-10 pb-16"><h1 class="text-5xl max-w-2xl">Protect what matters from wildfire.</h1>
      <p class="mt-4 max-w-xl opacity-90">Five categories of cover, instant risk-based quotes and a transparent claims journey.</p></div></header>
  <section class="max-w-6xl mx-auto px-6 py-12">
    <h2 class="text-3xl text-primary mb-6">Choose your cover</h2>
    <div class="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
      <a *ngFor="let c of cats" class="card hover:shadow-lg transition block" [routerLink]="['/category', c.slug]">
        <h3 class="text-xl text-primary">{{ c.name }}</h3><p class="text-sm mt-2 text-gray-600">{{ c.desc }}</p>
        <span class="inline-block mt-4 text-fuchsia font-semibold">View 5 plans →</span></a>
    </div></section>`
})
export class Home { cats = CATALOG; }
