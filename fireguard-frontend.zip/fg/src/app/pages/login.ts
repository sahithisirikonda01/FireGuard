import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { NgIf } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../core/auth.service';
@Component({
  selector: 'fg-login', standalone: true, imports: [NgIf, ReactiveFormsModule, RouterLink], changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
  <div class="min-h-screen grid place-items-center bg-warm p-4"><form class="card w-full max-w-sm space-y-4" [formGroup]="f" (ngSubmit)="go()">
    <h1 class="text-3xl text-primary">Welcome back</h1>
    <div><input class="inp" type="email" placeholder="Email" formControlName="email"><p class="err" *ngIf="f.controls.email.touched && f.controls.email.invalid">Valid email required</p></div>
    <div><input class="inp" type="password" placeholder="Password" formControlName="password"><p class="err" *ngIf="f.controls.password.touched && f.controls.password.invalid">Password required</p></div>
    <p class="err" *ngIf="err()">{{ err() }}</p>
    <button class="btn w-full" [disabled]="busy()">Login</button>
    <p class="text-sm text-center">New here? <a routerLink="/register" class="text-primary font-semibold">Register</a></p></form></div>`
})
export class Login {
  private auth = inject(AuthService); private router = inject(Router); private route = inject(ActivatedRoute);
  f = inject(FormBuilder).nonNullable.group({ email: ['', [Validators.required, Validators.email]], password: ['', Validators.required] });
  err = signal(''); busy = signal(false);
  go() {
    if (this.f.invalid) { this.f.markAllAsTouched(); return; }
    this.busy.set(true);
    this.auth.login(this.f.getRawValue()).subscribe({
      next: () => this.router.navigateByUrl(this.route.snapshot.queryParamMap.get('returnUrl') ?? this.auth.homeFor()),
      error: e => { this.err.set(e.error?.message ?? 'Login failed'); this.busy.set(false); } });
  }
}
