# FireGuard frontend
Angular standalone + Tailwind frontend scaffold aligned to the FireGuard microservices and claim lifecycle.

## Roles
Customer registers/login normally. Admin is hardcoded. Surveyors are intended to be created/approved by Admin; the surveyor registration page is retained only for backend compatibility because the project document contains `/api/auth/register/surveyor`.

## Public website
Home, About, Coverage, FAQ, Login, Customer Registration. Coverage presents five categories with five sub-types each. Get Quote routes users into authenticated Customer flow.

## Customer flow
Login -> Dashboard -> Get Quote -> ProductAPI -> RiskQuoteAPI -> Low/Medium auto-approved or High/VeryHigh PendingReview -> Admin review -> Accept -> PolicyAPI -> PendingPayment -> simulated payment -> Active Policy -> Claim -> PendingAssessment -> Admin assigns surveyor -> Assigned -> Surveyor investigation -> SurveySubmitted -> Admin decision -> Approved/Rejected -> simulated coverage payout -> Completed.

## Backend endpoints
Auth: POST /api/auth/login, POST /api/auth/register/customer, GET /api/auth/profile, POST /api/auth/logout.
Customer: GET /api/customers/me.
Products: GET /api/products, GET /api/products/{id}, admin CRUD.
Quotes: POST /api/riskquotes, GET /api/riskquotes/{id}, GET /api/riskquotes/my, GET /api/riskquotes/admin/pending, PUT /api/riskquotes/admin/{id}/approve, PUT /api/riskquotes/admin/{id}/reject.
Policies: POST /api/policies, POST /api/policies/{id}/payment, GET /api/policies/{id}, GET /api/policies/my, GET /api/policies/admin/all.
Claims: POST /api/claims, GET /api/claims/my, GET /api/claims/{id}, POST /api/claims/{claimId}/documents, GET /api/claims/{claimId}/documents, GET /api/claims/admin/pending, GET /api/claims/admin/all, PUT /api/claims/{id}/assign, PUT /api/claims/{id}/start-investigation, PUT /api/claims/{id}/survey-report, PUT /api/claims/{id}/decision, POST /api/claims/{id}/payment, GET /api/claims/surveyor/my.
Surveyors: GET /api/surveyors/pending, GET /api/surveyors/approved, PUT /api/surveyors/{userId}/approve, PUT /api/surveyors/{userId}/reject.

## Frontend requirements covered
Tailwind, standalone components/templates, data binding, services, async HTTP, signals, auth/role guards, interceptor, routes, lazy loading, session persistence across refresh, protected-route redirect, reactive forms/validation, component outputs, ChangeDetectorRef example, centralized API service and lightweight signal-based state through AuthService.

## Edge cases to preserve
401 -> clear session/login; 403 -> unauthorized; 404 -> not found state; 400 -> show backend validation message; 5xx/connection -> retry/error state; expired quote -> cannot create policy; PendingReview -> no Accept; rejected quote -> no policy; no active policy -> claim button/selection unavailable; claim upload >10 MB -> reject client-side; surveyor cannot make final decision; Approved claim only enables coverage payment; Completed only after payout; refresh keeps the same protected route because sessionStorage retains JWT/user state.

## Configure gateway
Edit `src/environments/environment.ts` and `environment.prod.ts` with your Ocelot gateway URL.

## Run
npm install
npm start

## Important
The exact ProductAPI/ClaimAPI response property names must match your final backend DTOs. If your controller route or DTO differs, change only the corresponding service/model rather than calling another service's database.
