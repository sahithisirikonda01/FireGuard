# FireGuard Frontend Deployment

1. Install Node.js and npm.
2. From this folder run `npm install`.
3. Set the Ocelot gateway URL in `src/environments/environment.ts` and `environment.prod.ts`.
4. Run `npm start` for local development.
5. Run `npm run build` for a production build. Deploy `dist/fireguard/browser` to a static web server.
6. Configure the server to return `index.html` for unknown application routes so refreshes such as `/customer/dashboard` and `/admin/claims/12` remain in the same page.

## Backend prerequisites
Start Ocelot and all six APIs. The gateway must allow the Angular origin through CORS. The supplied gateway currently has `https://localhost:5000` as its base URL.

## Current five-category handling
The public website has all five requested categories and five sub-types in each. The supplied backend has three quoteable products, so only Home, Farm and Business enter the live RiskQuoteAPI flow. Vehicle/Transportation and Community/Liability currently show a specialist-request message instead of inventing unsupported quote API data.
