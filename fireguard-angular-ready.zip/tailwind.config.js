module.exports={content:['./src/**/*.{html,ts}'],theme:{extend:{colors:{fg:{magenta:'#8A004F',pink:'#E5007D',blue:'#005A9C',gray:'#F4F4F4',charcoal:'#1c1f27'}}}},plugins:[]};
