# FireGuard Angular Frontend

Angular + Tailwind frontend aligned with the supplied FireGuard backend documentation and UI wireframes.

- Angular standalone components
- Tailwind CSS
- Reactive forms and validation
- Signals for authentication/session and product state
- Lazy-loaded route components
- Auth guard + role guard
- JWT interceptor with refresh-token retry
- localStorage session persistence so browser refresh stays on the same route
- Customer, Admin and Surveyor dashboards
- Public insurance website with 5 categories × 5 sub-types
- Simulated premium payment and claim coverage payout

## API Gateway
`src/environments/environment.ts` uses `https://localhost:5000`, matching the Ocelot gateway in the supplied backend code. Change it for deployment.

## Important domain alignment
The backend currently has three quoteable ProductAPI products: Wildfire Home, Wildfire Farm and Wildfire Business. The public website contains all five requested categories. Vehicle/Transportation and Community/Liability are presented as specialist-request categories until those two are added as quoteable backend products.

The supplied backend currently exposes surveyor registration as `/api/auth/register/surveyor`, creating a pending/inactive surveyor. The Admin portal uses that flow and then approves the surveyor from Surveyor Approvals; the surveyor can then use the normal Login page. This avoids inventing an unsupported Admin-only surveyor endpoint.
