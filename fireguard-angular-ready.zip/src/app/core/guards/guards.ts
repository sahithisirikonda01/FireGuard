import {CanActivateFn,Router} from '@angular/router';import {inject} from '@angular/core';import {AuthService} from '../services/auth.service';
export const authGuard:CanActivateFn=(r,s)=>{const a=inject(AuthService);return a.loggedIn()?true:inject(Router).createUrlTree(['/login'],{queryParams:{returnUrl:s.url}})};
export const roleGuard:CanActivateFn=r=>{const a=inject(AuthService);const roles=(r.data?.['roles']||[]) as string[];return roles.includes(String(a.role()))?true:inject(Router).createUrlTree([a.home()])};
