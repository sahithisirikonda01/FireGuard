import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';


import { PolicyService } from '../../../core/services/policy-service';
import { Policy } from '../../../core/models/policy/policy.models';


@Component({
  selector: 'fg-admin-policies',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink
  ],
  templateUrl: './policies-component.html'
})
export class AdminPoliciesComponent implements OnInit {


  private policyService = inject(PolicyService);


  policies: Policy[] = [];
  filteredPolicies: Policy[] = [];


  searchText = '';
  policyStatusFilter = 'All';
  paymentStatusFilter = 'All';


  loading = false;
  unauthorized = false;
  notFound = false;
  serverError = false;


  errorMessage = '';


  ngOnInit(): void {
    this.loadPolicies();
  }


  loadPolicies(): void {


    this.loading = true;


    this.policyService.getAll().subscribe({


      next: (data) => {


        this.policies = data;


        this.filteredPolicies = data;


        this.loading = false;


      },


      error: (error) => {


        this.loading = false;


        if (
          error.status === 401 ||
          error.status === 403
        ) {


          this.unauthorized = true;


        }
        else if (
          error.status === 404
        ) {


          this.notFound = true;


        }
        else {


          this.serverError = true;


          this.errorMessage =
            error.error?.message ||
            'Failed to load policies.';
        }
      }
    });


  }


  filterPolicies(): void {
    const search = this.searchText.trim().toLowerCase();
    this.filteredPolicies = this.policies.filter(policy => {
      const matchesSearch = !search || [policy.policyNumber, policy.quoteNumber, policy.productName, this.getPolicyStatus(policy.policyStatus), this.getPaymentStatus(policy.paymentStatus)].some(value => String(value ?? '').toLowerCase().includes(search));
      const matchesPolicyStatus = this.policyStatusFilter === 'All' || String(+policy.policyStatus) === this.policyStatusFilter;
      const matchesPaymentStatus = this.paymentStatusFilter === 'All' || String(+policy.paymentStatus) === this.paymentStatusFilter;
      return matchesSearch && matchesPolicyStatus && matchesPaymentStatus;
    });
  }



  getPolicyStatus(status: any): string {


    switch (+status) {


      case 1:
        return 'Pending Payment';


      case 2:
        return 'Active';


      case 3:
        return 'Expired';


      case 4:
        return 'Cancelled';


      default:
        return 'Unknown';
    }
  }


  getPaymentStatus(status: any): string {


    switch (+status) {


      case 1:
        return 'Pending';


      case 2:
        return 'Paid';


      case 3:
        return 'Failed';


      default:
        return 'Unknown';
    }
  }


  getPolicyBadge(status: any): string {


    switch (+status) {


      case 1:
        return 'bg-[#EAE5DF] text-[#75013F]';


      case 2:
        return 'bg-[#FE3082] text-white';


      case 3:
        return 'bg-[#f5f2ef] text-[#75013F]';


      case 4:
        return 'bg-[#75013F] text-white';


      default:
        return 'bg-[#EAE5DF] text-[#75013F]';
    }
  }


  getPaymentBadge(status: any): string {


    switch (+status) {


      case 1:
        return 'bg-[#EAE5DF] text-[#75013F]';


      case 2:
        return 'bg-[#FE3082] text-white';


      case 3:
        return 'bg-[#75013F] text-white';


      default:
        return 'bg-[#EAE5DF] text-[#75013F]';
    }
  }
}
