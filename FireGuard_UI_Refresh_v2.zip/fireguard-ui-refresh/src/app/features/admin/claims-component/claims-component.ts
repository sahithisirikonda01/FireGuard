import { Component, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


import { ClaimService } from '../../../core/services/claim-service';


import {
  Claim,
  Surveyor
} from '../../../core/models/claim/claim.models';


@Component({
  selector: 'fg-admin-claims',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    FormsModule
  ],
  templateUrl: './claims-component.html'
})
export class ClaimsComponent {


  private claimService = inject(ClaimService);


  claims = signal<Claim[]>([]);
  filteredClaims = signal<Claim[]>([]);


  surveyors = signal<Surveyor[]>([]);


  searchText = '';
  statusFilter = 'All';
  errorMessage = '';
  successMessage = '';


  showAssignModal = false;


  selectedClaimId: number | null = null;


  selectedSurveyorId: number | null = null;


  constructor() {


    this.loadClaims();


    this.loadSurveyors();
  }


  loadClaims(): void {


    this.claimService
      .getAll()
      .subscribe({


        next: (data) => {


          this.errorMessage = '';
          this.claims.set(data);


          this.filteredClaims.set(data);


        },


        error: (error) => {


          this.errorMessage = error?.error?.message || 'Failed to load claims. Please refresh or sign in again.';


        }


      });


  }


  loadSurveyors(): void {


    this.claimService
      .approvedSurveyors()
      .subscribe({


        next: (data) => {


          this.surveyors.set(data);


        },


        error: (error) => {


          console.error(
            'Failed to load surveyors',
            error
          );


        }


      });


  }


  filterClaims(): void {


    const search =
      this.searchText
        .trim()
        .toLowerCase();


    this.filteredClaims.set(
      this.claims().filter(claim => {
        const matchesStatus = this.statusFilter === 'All' || String(+claim.status) === this.statusFilter;
        const matchesSearch = !search || (

        claim.claimNumber
          ?.toLowerCase()
          .includes(search)


        ||


        claim.policyNumber
          ?.toLowerCase()
          .includes(search)


        ||


        claim.productName
          ?.toLowerCase()
          .includes(search)


        ||


        claim.surveyorName
          ?.toLowerCase()
          .includes(search)


        ||


        this.getStatusText(
          claim.status
        )
          .toLowerCase()
          .includes(search)
        );
        return matchesStatus && matchesSearch;
      })
    );


  }


  openAssignModal(
    claimId: number
  ): void {


    this.selectedClaimId =
      claimId;


    this.selectedSurveyorId =
      null;


    this.showAssignModal =
      true;


  }


  assignSurveyor(): void {


    if (
      !this.selectedClaimId ||
      !this.selectedSurveyorId
    ) {
      return;
    }


    this.claimService
      .assign(
        this.selectedClaimId,
        this.selectedSurveyorId
      )
      .subscribe({


        next: () => {


          this.showAssignModal = false;
          this.successMessage = 'Surveyor assigned successfully.';
          this.loadClaims();


        },


        error: error => {


          this.errorMessage = error?.error?.message || 'Failed to assign surveyor. Please try again.';


        }


      });


  }


  closeModal(): void {


    this.showAssignModal =
      false;


    this.selectedClaimId =
      null;


    this.selectedSurveyorId =
      null;


  }


  getStatusText(status: any): string {


    switch (+status) {


      case 1:
        return 'Pending Assignment';


      case 2:
        return 'Assigned';


      case 3:
        return 'Under Investigation';


      case 4:
        return 'Survey Submitted';


      case 5:
        return 'Approved';


      case 6:
        return 'Rejected';


      default:
        return 'Unknown';
    }
  }


  getBadgeClass(status: any): string {


    switch (+status) {


      case 1:
        return 'bg-[#EAE5DF] text-[#75013F]';


      case 2:
        return 'bg-[#f5f2ef] text-[#75013F]';


      case 3:
        return 'bg-[#FE3082] text-white';


      case 4:
        return 'bg-[#FE3082] text-white';


      case 5:
        return 'bg-[#75013F] text-white';


      case 6:
        return 'bg-[#75013F] text-white';


      default:
        return 'bg-[#EAE5DF] text-[#75013F]';


    }


  }


}
