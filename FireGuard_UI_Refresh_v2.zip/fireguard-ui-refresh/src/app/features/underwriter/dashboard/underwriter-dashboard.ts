import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { RiskQuoteService } from '../../../core/services/risk-quote-service';
import { Quote } from '../../../core/models/quote/quote.models';
import { Observable } from 'rxjs';

@Component({ selector: 'fg-underwriter-dashboard', standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './underwriter-dashboard.html', styleUrl: './underwriter-dashboard.css' })
export class UnderwriterDashboardComponent {
  private quoteService = inject(RiskQuoteService);
  private cdr = inject(ChangeDetectorRef);
  quotes = signal<Quote[]>([]);
  filteredQuotes = signal<Quote[]>([]);
  loading = signal(false);
  errorMessage = signal('');
  successMessage = signal('');
  searchText = '';
  statusFilter = 'PendingReview';
  selectedQuote: Quote | null = null;
  action: 'offer' | 'information' | 'reject' = 'offer';
  offeredPremium: number | null = null;
  offeredCoverage: number | null = null;
  remarks = '';
  validityDays = 7;
  constructor() { this.loadQuotes(); }
  loadQuotes(): void {
    this.loading.set(true); this.errorMessage.set('');
    this.quoteService.getUnderwriterPending().subscribe({
      next: rows => { this.quotes.set(rows || []); this.applyFilters(); this.loading.set(false); this.cdr.markForCheck(); },
      error: err => { this.loading.set(false); this.errorMessage.set(err?.error?.message || 'Unable to load underwriting queue. Confirm that the API exposes /api/riskquotes/underwriter/pending and the signed-in user has the Underwriter role.'); this.cdr.markForCheck(); }
    });
  }
  applyFilters(): void {
    const term = this.searchText.trim().toLowerCase();
    this.filteredQuotes.set(this.quotes().filter(q => {
      const matchesTerm = !term || [q.quoteNumber, q.productName, q.riskLevel, q.status, q.userId].some(v => String(v ?? '').toLowerCase().includes(term));
      const matchesStatus = this.statusFilter === 'All' || this.statusName(q.status) === this.statusFilter;
      return matchesTerm && matchesStatus;
    }));
  }
  statusName(status: Quote['status']): string {
    if (typeof status === 'number') return ({1:'PendingReview',2:'Approved',3:'Rejected',4:'Expired',5:'Accepted',6:'OfferIssued',7:'AdditionalInformationRequired',8:'Declined'} as Record<number,string>)[status] || 'Unknown';
    return status;
  }
  count(status: string): number { return this.quotes().filter(q => this.statusName(q.status) === status).length; }
  highRiskCount(): number { return this.quotes().filter(q => ['High', 'VeryHigh'].includes(q.riskLevel)).length; }
  lowMediumRiskCount(): number { return this.quotes().filter(q => ['Low', 'Medium'].includes(q.riskLevel)).length; }
  openAction(quote: Quote, action: 'offer'|'information'|'reject'): void {
    this.selectedQuote = quote; this.action = action; this.remarks = ''; this.offeredPremium = quote.finalPremium; this.offeredCoverage = quote.coverageAmount; this.validityDays = 7; this.errorMessage.set(''); this.successMessage.set('');
  }
  closeAction(): void { this.selectedQuote = null; this.remarks = ''; }
  submitAction(): void {
    if (!this.selectedQuote) return;
    const id = this.selectedQuote.id;
    this.errorMessage.set(''); this.successMessage.set('');
    let request: Observable<Quote>;
    if (this.action === 'offer') {
      if (this.offeredPremium == null || this.offeredPremium <= 0 || this.offeredCoverage == null || this.offeredCoverage <= 0 || !Number.isInteger(this.validityDays) || this.validityDays < 1 || this.validityDays > 365) { this.errorMessage.set('Enter a positive premium and coverage and an offer validity between 1 and 365 days.'); return; }
      if (this.offeredCoverage > this.selectedQuote.coverageAmount) { this.errorMessage.set('Offered coverage cannot exceed the calculated coverage shown for this quote.'); return; }
      request = this.quoteService.issueOffer(id, { offeredPremium: this.offeredPremium, offeredCoverageAmount: this.offeredCoverage, remarks: this.remarks.trim(), offerValidityDays: this.validityDays });
    } else if (this.action === 'information') {
      if (this.remarks.trim().length < 3) { this.errorMessage.set('Enter the additional information required.'); return; }
      request = this.quoteService.requestAdditionalInformation(id, { message: this.remarks.trim() });
    } else {
      if (this.remarks.trim().length < 3) { this.errorMessage.set('Enter a reason for rejection.'); return; }
      request = this.quoteService.rejectUnderwriterQuote(id, { remarks: this.remarks.trim() });
    }
    request.subscribe({
      next: () => { this.successMessage.set(this.action === 'offer' ? 'Offer issued successfully.' : this.action === 'information' ? 'Information request sent.' : 'Quote rejected.'); this.selectedQuote = null; this.loadQuotes(); this.cdr.markForCheck(); },
      error: err => { this.errorMessage.set(err?.error?.message || 'The action could not be completed. Check the API route and request DTO.'); this.cdr.markForCheck(); }
    });
  }
}
