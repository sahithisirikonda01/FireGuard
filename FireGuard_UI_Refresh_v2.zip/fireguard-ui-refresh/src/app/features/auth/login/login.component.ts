import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  inject
} from '@angular/core';


import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import {
  ActivatedRoute
}
from '@angular/router';
import {
  Router,
  RouterLink
} from '@angular/router';


import { AuthService } from '../../../core/services/auth-service';


@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink
  ],
  templateUrl: './login.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginComponent {


  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);
  private route =
  inject(
    ActivatedRoute
  );
  loading = false;
  errorMessage = '';


  readonly form = this.fb.nonNullable.group({


  email: [
    '',
    [
      Validators.required,
      Validators.email
    ]
  ],


  password: [
    '',
    [
      Validators.required,
      Validators.minLength(7)
    ]
  ]


});


  submit(): void {


    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }


    this.loading = true;
    this.errorMessage = '';


    this.auth.login(
      this.form.getRawValue()
    ).subscribe({


      next: () => {


        const returnUrl =
          this.route.snapshot
            .queryParamMap
            .get(
              'returnUrl'
            );


        if (returnUrl) {


          this.router.navigateByUrl(
            returnUrl
          );


          return;


        }


        const role =
          this.auth.user()?.role?.toLowerCase();


        switch (role) {


          case 'admin':
            this.router.navigate(
              ['/admin/dashboard']
            );
            break;


          case 'surveyor':
            this.router.navigate(['/surveyor/dashboard']);
            break;

          case 'underwriter':
            this.router.navigate(['/underwriter/dashboard']);
            break;


          default:
            this.router.navigate(
              ['/customer/dashboard']
            );
        }
      },


      error: error => {


        this.errorMessage =
          error?.error?.message ??
          'Unable to sign in.';


        this.loading = false;


        this.cdr.markForCheck();
      }
    });
  }


  get email() {
    return this.form.controls.email;
  }


  get password() {
    return this.form.controls.password;
  }
}
