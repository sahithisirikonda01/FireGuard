import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth-service';

@Component({ selector: 'fg-account-profile', standalone: true, imports: [CommonModule, RouterLink], templateUrl: './account-profile.html' })
export class AccountProfileComponent {
  private auth = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);
  readonly user = this.auth.user;
  get initial(): string { return (this.user()?.username || this.user()?.email || 'U').charAt(0).toUpperCase(); }
  refresh(): void { this.cdr.markForCheck(); }
  logout(): void { this.auth.logout(); this.cdr.markForCheck(); }
}
