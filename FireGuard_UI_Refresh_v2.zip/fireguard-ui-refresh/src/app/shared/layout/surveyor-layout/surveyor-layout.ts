import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../../../core/services/auth-service';
import { SurveyorService } from '../../../core/services/surveyor-service';

@Component({ selector: 'fg-surveyor-layout', standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './surveyor-layout.html', styleUrl: './surveyor-layout.css' })
export class SurveyorLayout {
  private authService = inject(AuthService);
  private surveyorService = inject(SurveyorService);
  private cdr = inject(ChangeDetectorRef);
  readonly profile = this.authService.user;
  status = signal<number>(0);
  displayInitial = 'S';
  constructor() { this.loadProfile(); }
  loadProfile(): void {
    this.surveyorService.getProfile().subscribe({
      next: profile => { this.status.set(Number(profile.status)); this.displayInitial = (profile.fullName || 'S').charAt(0).toUpperCase(); this.cdr.markForCheck(); },
      error: () => { this.displayInitial = (this.profile()?.email || 'S').charAt(0).toUpperCase(); this.cdr.markForCheck(); }
    });
  }
  logout(): void { this.authService.logout(); this.cdr.markForCheck(); }
}
