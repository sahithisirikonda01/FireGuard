import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../../../core/services/auth-service';

@Component({ selector: 'fg-customer-layout', standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './customer-layout.html', styleUrl: './customer-layout.css' })
export class CustomerLayoutComponent {
  private authService = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);
  readonly profile = this.authService.user;
  get initial(): string { return (this.profile()?.username || this.profile()?.email || 'C').charAt(0).toUpperCase(); }
  logout(): void { this.authService.logout(); this.cdr.markForCheck(); }
}
