import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../../../core/services/auth-service';

@Component({
  selector: 'fg-admin-layout', standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './admin-layout.html', styleUrl: './admin-layout.css'
})
export class AdminLayoutComponent {
  private authService = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);
  readonly profile = this.authService.user;
  get initial(): string { return (this.profile()?.username || this.profile()?.email || 'A').charAt(0).toUpperCase(); }
  logout(): void { this.authService.logout(); this.cdr.markForCheck(); }
}
