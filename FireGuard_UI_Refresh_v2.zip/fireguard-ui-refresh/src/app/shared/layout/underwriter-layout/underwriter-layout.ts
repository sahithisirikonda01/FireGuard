import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../../../core/services/auth-service';
@Component({ selector: 'fg-underwriter-layout', standalone: true, imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive], templateUrl: './underwriter-layout.html', styleUrl: './underwriter-layout.css' })
export class UnderwriterLayoutComponent {
  private auth = inject(AuthService); private cdr = inject(ChangeDetectorRef); readonly profile = this.auth.user;
  get initial(): string { return (this.profile()?.username || this.profile()?.email || 'U').charAt(0).toUpperCase(); }
  logout(): void { this.auth.logout(); this.cdr.markForCheck(); }
}
