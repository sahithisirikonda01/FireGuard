import { Routes } from '@angular/router';


import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';


import { PublicLayoutComponent } from './shared/layout/public-layout/public-layout';
import { CustomerLayoutComponent } from './shared/layout/customer-layout/customer-layout';
import { AdminLayoutComponent } from './shared/layout/admin-layout/admin-layout';
import { SurveyorLayout } from './shared/layout/surveyor-layout/surveyor-layout';
import { UnderwriterLayoutComponent } from './shared/layout/underwriter-layout/underwriter-layout';
import { UnderwriterDashboardComponent } from './features/underwriter/dashboard/underwriter-dashboard';
import { AccountProfileComponent } from './features/shared/profile/account-profile';




import { ApplicationsComponent } from './features/customer/applications/applications';


import { ApplicationDetailsComponent } from './features/customer/application-details/application-details';


import { ClaimsComponent  }
from './features/admin/claims-component/claims-component';


import { ClaimDetailsComponent }
from './features/admin/claim-details-component/claim-details-component';
import { AdminPoliciesComponent } from './features/admin/policies-component/policies-component';
import { AdminApplicationDetailsComponent } from './features/admin/application-details-component/application-details-component';
import { AdminProductsComponent } from './features/admin/products-component/products-component';




import { ProductsComponent } from './features/customer/products/products';


import { SurveyorsComponent }
from './features/admin/surveyors-component/surveyors-component';


import { UsersComponent }
from './features/admin/users-component/users-component';
// Public
import { HomeComponent } from './features/public/home/home';
import { AboutComponent } from './features/public/about/about';
import { Coverage } from './features/public/coverage/coverage';
import { FaqComponent } from './features/public/faq/faq';
import {  InsuranceDetailsComponent } from './features/public/insurance-details/insurance-details';


// Auth
import { LoginComponent } from './features/auth/login/login.component';
import { RegisterSelection} from './features/auth/register-selection/register-selection';
import { CustomerRegisterComponent } from './features/auth/customer-register/customer-register';
import { SurveyorRegisterComponent } from './features/auth/surveyor-register/surveyor-register';


// Customer
import { DashboardComponent } from './features/customer/dashboard/dashboard';
import { QuoteDetailsComponent } from './features/customer/quote-details/quote-details';
import { PoliciesComponent } from './features/customer/policies/policies';
import { PolicyDetailsComponent } from './features/customer/policy-details/policy-details';
import { GetQuoteComponent } from './features/customer/get-quote/get-quote';
import { NewClaimComponent } from './features/customer/new-claim/new-claim';
import { PaymentComponent } from './features/customer/payments/payments';
import { CustomerProfileComponent } from './features/customer/profile/profile';
import { ClaimsComponent as CustomeClaims } from './features/customer/claims/claims';
import { ClaimDetailsComponent as CustomerClaimDetails} from './features/customer/claim-details/claim-details';


// Surveyor
import { DashboardComponent as SurveyorDashboardComponent } from './features/surveyor/dashboard/dashboard';
import { AssignedClaimsComponent }
from './features/surveyor/assigned-claims/assigned-claims';
import {
  surveyorApprovalGuard
}
from './core/guards/surveyor-approval.guard';
import { ClaimDetails }
from './features/surveyor/claim-details/claim-details';
import { Resubmit } from './features/surveyor/resubmit/resubmit';
import { MySurveysComponent }
from './features/surveyor/my-surveys/my-surveys';


import { ReportsComponent }
from './features/surveyor/reports/reports';


import { SurveyorProfileComponent }
from './features/surveyor/profile/profile';


import { SurveyReport }
from './features/surveyor/survey-report/survey-report';


// Admin
import { DashboardComponent as AdminDashboardComponent }
from './features/admin/dashboard-component/dashboard-component';
import { AdminApplicationsComponent } from './features/admin/application-component/application-component';


export const routes: Routes = [


  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },


  // PUBLIC ROUTES
  {
    path: '',
    component: PublicLayoutComponent,
    children: [
      { path: 'home', component: HomeComponent },
      { path: 'about', component: AboutComponent },
      { path: 'coverage', component: Coverage },
      { path: 'faq', component: FaqComponent },
      { path: 'login', component: LoginComponent },
      {path:'registerselection',component:RegisterSelection},
      { path: 'customer-register', component: CustomerRegisterComponent },
      { path: 'surveyor-register', component: SurveyorRegisterComponent },
      {
  path: 'coverage/:category',
  component: Coverage
},


{
  path: 'coverage/:category/:product',
  component: InsuranceDetailsComponent
}
    ]
  },


  // CUSTOMER
 {
  path: 'customer',
  component: CustomerLayoutComponent,
  canActivate: [
    authGuard,
    roleGuard(['Customer'])
  ],
  children: [


    {
      path: 'dashboard',
      component: DashboardComponent
    },


    {
      path: 'applications',
      component: ApplicationsComponent
    },


    {
      path: 'application-details/:id',
      component: ApplicationDetailsComponent
    },


    {
      path: 'products',
      component: ProductsComponent
    },


    {
      path: 'quote',
      component: GetQuoteComponent
    },


    {
      path: 'quote-details/:id',
      component: QuoteDetailsComponent
    },


    {
      path: 'policies',
      component: PoliciesComponent
    },


    {
      path: 'policy-details/:id',
      component: PolicyDetailsComponent
    },


    {
      path: 'claims',
      component: CustomeClaims
    },


    {
      path: 'claim-details/:id',
      component: CustomerClaimDetails
    },


    {
      path: 'new-claim',
      component: NewClaimComponent
    },


    {
  path: 'payments',
  component: PaymentComponent
},


    {
      path: 'profile',
      component: CustomerProfileComponent
    },


    {
      path: '',
      redirectTo: 'dashboard',
      pathMatch: 'full'
    }
  ]
},


  // ADMIN
  {
  path: 'admin',
  component: AdminLayoutComponent,
  canActivate: [
    authGuard,
    roleGuard(['Admin'])
  ],
  children: [


    {
      path: 'dashboard',
      component: AdminDashboardComponent
    },
    { path: 'applications', component: AdminApplicationsComponent },
    { path: 'profile', component: AccountProfileComponent },




    {
      path: 'claims',
      component: ClaimsComponent
    },


    {
      path: 'claims/:id',
      component: ClaimDetailsComponent
    },


    {
      path: 'policies',
      component: AdminPoliciesComponent
    },


    {
      path: 'products',
      component: AdminProductsComponent
    },


    {
      path: 'surveyors',
      component: SurveyorsComponent
    },


    {
      path: 'users',
      component: UsersComponent
    },


    {
      path: '',
      redirectTo: 'dashboard',
      pathMatch: 'full'
    }
  ]
},


//Surveyor


    {
  path: 'surveyor',
  component: SurveyorLayout,
  canActivate: [
    authGuard,
    //roleGuard(['Surveyor'])
  ],
  children: [


    {
      path: 'dashboard',
      component: SurveyorDashboardComponent
    },


    {
  path: 'assigned-claims',
  component: AssignedClaimsComponent,
  canActivate: [
    surveyorApprovalGuard
  ]
},


    {
  path: 'claim/:id',
  component: ClaimDetails,
  canActivate: [
    surveyorApprovalGuard
  ]
},


    {
  path: 'claim/:id/report',
  component: SurveyReport,
  canActivate: [
    surveyorApprovalGuard
  ]
},


    {
  path: 'my-surveys',
  component: MySurveysComponent,
  canActivate: [
    surveyorApprovalGuard
  ]
},


    {
  path: 'reports',
  component: ReportsComponent,
  canActivate: [
    surveyorApprovalGuard
  ]
},
    {
  path: 'resubmit',
  component: Resubmit
},


    {
      path: 'profile',
      component: SurveyorProfileComponent
    },


    {
      path: '',
      redirectTo: 'dashboard',
      pathMatch: 'full'
    }
  ]
},


  {
    path: 'underwriter',
    component: UnderwriterLayoutComponent,
    canActivate: [authGuard, roleGuard(['Underwriter'])],
    children: [
      { path: 'dashboard', component: UnderwriterDashboardComponent },
      { path: 'profile', component: AccountProfileComponent },
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' }
    ]
  },

  {
    path: 'unauthorized',
    component: AboutComponent
  },


  {
    path: '**',
    redirectTo: 'home'
  }
];
