import { Injectable, inject } from '@angular/core';
import { ApiService } from './api-service';
import { Quote, CreateQuoteRequest, IssueOfferRequest, RequestInformationRequest, RejectQuoteRequest } from '../models/quote/quote.models';

@Injectable({ providedIn: 'root' })
export class RiskQuoteService {
  private api = inject(ApiService);
  create(request: CreateQuoteRequest) { return this.api.post<Quote>('/riskquotes', request); }
  getMine() { return this.api.get<Quote[]>('/riskquotes/my'); }
  getById(id: number) { return this.api.get<Quote>(`/riskquotes/${id}`); }
  // Keep this alias for older Admin screens; Underwriter uses the dedicated route below.
  getPending() { return this.api.get<Quote[]>('/riskquotes/admin/pending'); }
  getUnderwriterPending() { return this.api.get<Quote[]>('/riskquotes/underwriter/pending'); }
  issueOffer(id: number, request: IssueOfferRequest) { return this.api.put<Quote>(`/riskquotes/underwriter/${id}/offer`, request); }
  requestAdditionalInformation(id: number, request: RequestInformationRequest) { return this.api.put<Quote>(`/riskquotes/underwriter/${id}/request-information`, request); }
  rejectUnderwriterQuote(id: number, request: RejectQuoteRequest) { return this.api.put<Quote>(`/riskquotes/underwriter/${id}/reject`, request); }
  approve(id: number) { return this.api.put(`/riskquotes/admin/${id}/approve`, {}); }
  reject(id: number, remarks: string) { return this.api.put(`/riskquotes/admin/${id}/reject`, { remarks }); }
  accept(id: number) { return this.api.put(`/riskquotes/${id}/accept`, {}); }
}
