export type RiskLevel = 'Low' | 'Medium' | 'High' | 'VeryHigh';
export type QuoteStatus = 'PendingReview' | 'Approved' | 'Rejected' | 'Expired' | 'Accepted' | 'OfferIssued' | 'AdditionalInformationRequired' | 'Declined' | number;
export interface CreateQuoteRequest {
  productId: number; propertyValue: number; landArea: number; constructionType: string;
  roofType: string; propertyAge: number; forestDistance: number; vegetationLevel: string;
  hasSmokeDetector: boolean; hasFireExtinguisher: boolean;
}
export interface Quote {
  id: number; quoteNumber: string; userId: string; productId: number; productName: string;
  riskScore: number; riskLevel: RiskLevel; finalPremium: number; coverageAmount: number;
  basePremium?: number; offeredPremium?: number | null; offeredCoverageAmount?: number | null;
  underwriterRemarks?: string | null; additionalInformationRequest?: string | null;
  rejectionReason?: string | null; offerIssuedAt?: string | null; offerExpiresAt?: string | null;
  status: QuoteStatus; expiryDate: string; createdAt?: string;
}
export interface IssueOfferRequest { offeredPremium?: number | null; offeredCoverageAmount?: number | null; remarks?: string; offerValidityDays: number; }
export interface RequestInformationRequest { message: string; }
export interface RejectQuoteRequest { remarks: string; }
