export type UserRole = 'Customer' | 'Admin' | 'Surveyor' | 'Underwriter';

export interface LoginRequest { email: string; password: string; }
export interface LoginResponse {
  accessToken: string; refreshToken: string; accessTokenExpiresAt: string;
  userId: string; email: string; role: UserRole;
}
export interface UserProfile {
  userId: string; email: string; username?: string; role: UserRole;
  isActive: boolean; surveyorStatus?: string;
}
export interface CustomerRegisterRequest { fullName: string; email: string; phone: string; address: string; password: string; }
export interface SurveyorRegisterRequest {
  fullName: string; email: string; phone: string; address: string;
  qualification: string; licenseNumber: string; experienceYears: number; password: string;
}
