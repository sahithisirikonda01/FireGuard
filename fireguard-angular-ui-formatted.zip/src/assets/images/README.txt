Place your wildfire hero image here as hero-wildfire.jpg
