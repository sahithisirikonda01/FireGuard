export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  accessToken: string;
  refreshToken?: string;
  role: string;
  userId?: string;
}

export interface RegisterCustomerRequest {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  password: string;
  confirmPassword: string;
}

export interface RegisterSurveyorRequest {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  qualification: string;
  licenseNumber: string;
  experienceYears: number;
  password: string;
  confirmPassword: string;
}
