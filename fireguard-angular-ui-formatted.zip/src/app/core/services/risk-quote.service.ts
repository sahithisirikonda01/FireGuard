import { Injectable } from '@angular/core';
import { ApiService } from './api.service';

export interface CreateQuoteRequest {
  productId: number;
  propertyValue: number;
  landArea: number;
  constructionType: string;
  roofType: string;
  propertyAge: number;
  forestDistance: number;
  vegetationLevel: string;
  hasSmokeDetector: boolean;
  hasFireExtinguisher: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class RiskQuoteService {
  constructor(private readonly api: ApiService) {}

  createQuote(request: CreateQuoteRequest) {
    return this.api.post('/api/riskquotes', request);
  }

  getMyQuotes() {
    return this.api.get('/api/riskquotes/my');
  }

  getQuote(id: number) {
    return this.api.get(`/api/riskquotes/${id}`);
  }
}
