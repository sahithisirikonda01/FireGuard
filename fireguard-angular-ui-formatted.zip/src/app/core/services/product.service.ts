import { Injectable } from '@angular/core';
import { ApiService } from './api.service';

export interface Product {
  id: number;
  code: string;
  name: string;
  description: string;
  basePremium: number;
  isActive: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  constructor(private readonly api: ApiService) {}

  getProducts() {
    return this.api.get<Product[]>('/api/products');
  }

  getProduct(id: number) {
    return this.api.get<Product>(`/api/products/${id}`);
  }
}
