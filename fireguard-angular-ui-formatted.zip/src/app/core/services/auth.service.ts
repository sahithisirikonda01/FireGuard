import { Injectable, signal } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from './api.service';
import {
  LoginRequest,
  LoginResponse,
  RegisterCustomerRequest
} from '../models/auth/auth.models';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  readonly isAuthenticated = signal(!!localStorage.getItem('accessToken'));

  constructor(
    private readonly api: ApiService,
    private readonly router: Router
  ) {}

  login(request: LoginRequest) {
    return this.api.post<LoginResponse>('/api/auth/login', request);
  }

  registerCustomer(request: RegisterCustomerRequest) {
    return this.api.post('/api/auth/register/customer', request);
  }

  saveSession(response: LoginResponse): void {
    localStorage.setItem('accessToken', response.accessToken);

    if (response.refreshToken) {
      localStorage.setItem('refreshToken', response.refreshToken);
    }

    localStorage.setItem('role', response.role);
    this.isAuthenticated.set(true);
  }

  getRole(): string {
    return localStorage.getItem('role') ?? '';
  }

  logout(): void {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('role');
    this.isAuthenticated.set(false);
    this.router.navigate(['/']);
  }
}
