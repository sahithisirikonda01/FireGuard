# FireGuard Angular UI

Angular frontend structure for the FireGuard Wildfire Insurance Management System.

## Run

```bash
npm install
ng serve
```

Configure the Ocelot Gateway URL in `src/environments/environment.ts`.

The source files in this package are intentionally formatted with normal line breaks and indentation.
